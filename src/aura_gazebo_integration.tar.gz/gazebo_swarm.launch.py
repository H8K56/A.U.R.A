"""
A.U.R.A. Gazebo + PX4 SITL Launch

Launches the complete A.U.R.A. stack with real PX4 SITL drones
in a Gazebo Classic earthquake world. This is the visual
simulation mode — drones are 3D rendered and physics-based.

Architecture:
  Gazebo Classic (earthquake_city.world)
    └── N × iris models (spawned at offset positions)
  N × PX4 SITL instances (unique ports per instance)
  N × MAVROS bridges (ROS 2 ↔ MAVLink)
  px4_mavros_bridge (MAVROS ↔ A.U.R.A. SwarmState/CoverageGoal)
  network_sim_node, coverage_calculator (network simulation)
  strategic_rl_node (positioning policy)
  mission_control_node (mission state machine)

Usage:
    # Full stack with 5 drones:
    ros2 launch aura_simulation gazebo_swarm.launch.py

    # 3 drones, headless (no GUI):
    ros2 launch aura_simulation gazebo_swarm.launch.py num_drones:=3 headless:=true

    # With dead zone injection:
    ros2 launch aura_simulation gazebo_swarm.launch.py inject_dead_zone:=true

Prerequisites:
    sudo apt install ros-humble-mavros ros-humble-mavros-extras
    sudo /opt/ros/humble/lib/mavros/install_geographiclib_datasets.sh
"""

import os
import math
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    ExecuteProcess,
    TimerAction,
    GroupAction,
    OpaqueFunction,
)
from launch.substitutions import LaunchConfiguration, PythonExpression
from launch.conditions import IfCondition, UnlessCondition
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    # ── Paths ────────────────────────────────────────────
    # Adjust these to match your container layout
    px4_dir = os.path.expanduser('~/PX4-Autopilot')
    px4_build = os.path.join(px4_dir, 'build', 'px4_sitl_default')
    gazebo_plugin_dir = os.path.join(
        px4_dir, 'build', 'px4_sitl_default', 'build_gazebo-classic')
    gazebo_model_dir = os.path.join(
        px4_dir, 'Tools', 'simulation', 'gazebo-classic',
        'sitl_gazebo-classic', 'models')
    gazebo_world_dir = os.path.join(
        px4_dir, 'Tools', 'simulation', 'gazebo-classic',
        'sitl_gazebo-classic', 'worlds')

    # A.U.R.A. paths
    aura_world_dir = os.path.expanduser('~/ws/worlds')

    # Package configs
    try:
        sim_pkg = get_package_share_directory('aura_simulation')
        sim_config = os.path.join(sim_pkg, 'config', 'sim_params.yaml')
    except Exception:
        sim_config = os.path.expanduser('~/ws/config/sim_params.yaml')

    try:
        net_pkg = get_package_share_directory('aura_network_sim')
        net_config = os.path.join(net_pkg, 'config', 'network_sim_params.yaml')
    except Exception:
        net_config = sim_config

    try:
        mc_pkg = get_package_share_directory('aura_mission_control')
        mc_config = os.path.join(mc_pkg, 'config', 'mission_control_params.yaml')
    except Exception:
        mc_config = sim_config

    return LaunchDescription([
        # ── Arguments ────────────────────────────────────
        DeclareLaunchArgument('num_drones', default_value='5'),
        DeclareLaunchArgument('headless', default_value='false',
            description='Run Gazebo without GUI (server only)'),
        DeclareLaunchArgument('world', default_value='earthquake_city',
            description='Gazebo world file name (without .world)'),
        DeclareLaunchArgument('auto_start', default_value='true'),
        DeclareLaunchArgument('inject_dead_zone', default_value='false'),
        DeclareLaunchArgument('use_baseline', default_value='true'),
        DeclareLaunchArgument('spawn_radius', default_value='5.0',
            description='Radius for initial drone spawn circle (m)'),

        # ── Environment setup via opaque function ────────
        OpaqueFunction(function=launch_setup, kwargs={
            'px4_dir': px4_dir,
            'px4_build': px4_build,
            'gazebo_plugin_dir': gazebo_plugin_dir,
            'gazebo_model_dir': gazebo_model_dir,
            'aura_world_dir': aura_world_dir,
            'sim_config': sim_config,
            'net_config': net_config,
            'mc_config': mc_config,
        }),
    ])


def launch_setup(context, *args, **kwargs):
    """Build the actual launch actions with resolved parameters"""
    px4_dir = kwargs['px4_dir']
    px4_build = kwargs['px4_build']
    gazebo_plugin_dir = kwargs['gazebo_plugin_dir']
    gazebo_model_dir = kwargs['gazebo_model_dir']
    aura_world_dir = kwargs['aura_world_dir']
    sim_config = kwargs['sim_config']
    net_config = kwargs['net_config']
    mc_config = kwargs['mc_config']

    num_drones = int(context.launch_configurations.get('num_drones', '5'))
    headless = context.launch_configurations.get('headless', 'false') == 'true'
    world_name = context.launch_configurations.get('world', 'earthquake_city')
    spawn_radius = float(context.launch_configurations.get('spawn_radius', '5.0'))

    # World file path
    world_file = os.path.join(aura_world_dir, f'{world_name}.world')
    if not os.path.exists(world_file):
        # Fallback to PX4 worlds
        world_file = os.path.join(
            px4_dir, 'Tools', 'simulation', 'gazebo-classic',
            'sitl_gazebo-classic', 'worlds', f'{world_name}.world')

    # ── Environment variables for Gazebo + PX4 ────────
    env = os.environ.copy()
    env['GAZEBO_PLUGIN_PATH'] = ':'.join(filter(None, [
        gazebo_plugin_dir,
        '/usr/lib/x86_64-linux-gnu/gazebo-11/plugins',
        env.get('GAZEBO_PLUGIN_PATH', ''),
    ]))
    env['GAZEBO_MODEL_PATH'] = ':'.join(filter(None, [
        gazebo_model_dir,
        os.path.join(aura_world_dir, '..', 'models'),
        env.get('GAZEBO_MODEL_PATH', ''),
    ]))
    env['LD_LIBRARY_PATH'] = ':'.join(filter(None, [
        os.path.join(px4_build, 'build_gazebo-classic'),
        env.get('LD_LIBRARY_PATH', ''),
    ]))

    actions = []

    # ═══ 1. GAZEBO SERVER ═══════════════════════════════
    gz_server_cmd = ['gzserver', '--verbose', world_file]
    actions.append(ExecuteProcess(
        cmd=gz_server_cmd,
        output='screen',
        additional_env={
            'GAZEBO_PLUGIN_PATH': env['GAZEBO_PLUGIN_PATH'],
            'GAZEBO_MODEL_PATH': env['GAZEBO_MODEL_PATH'],
            'LD_LIBRARY_PATH': env.get('LD_LIBRARY_PATH', ''),
        },
    ))

    # ═══ 2. GAZEBO CLIENT (GUI) ═════════════════════════
    if not headless:
        actions.append(TimerAction(
            period=2.0,
            actions=[ExecuteProcess(
                cmd=['gzclient', '--verbose'],
                output='screen',
                additional_env={
                    'GAZEBO_MODEL_PATH': env['GAZEBO_MODEL_PATH'],
                },
            )],
        ))

    # ═══ 3. PX4 SITL INSTANCES + SPAWN DRONES ══════════
    for i in range(num_drones):
        # Spawn position (circle around origin)
        angle = 2 * math.pi * i / num_drones
        spawn_x = spawn_radius * math.cos(angle)
        spawn_y = spawn_radius * math.sin(angle)

        # Port allocation per PX4 instance:
        #   SITL UDP: 14560 + i (Gazebo plugin)
        #   MAVLink:  14540 + i (MAVROS connects here)
        #   Sim:      14560 + i
        mavlink_udp_port = 14540 + i
        mavlink_tcp_port = 4560 + i

        # Spawn iris model in Gazebo
        spawn_cmd = [
            'gz', 'model',
            '--spawn-file', os.path.join(gazebo_model_dir, 'iris', 'iris.sdf'),
            '--model-name', f'iris_{i}',
            '-x', str(spawn_x),
            '-y', str(spawn_y),
            '-z', '0.1',
        ]

        actions.append(TimerAction(
            period=3.0 + i * 1.5,  # Stagger spawns
            actions=[ExecuteProcess(
                cmd=spawn_cmd,
                output='screen',
            )],
        ))

        # PX4 SITL instance
        px4_env = {
            'PX4_SYS_AUTOSTART': '4001',  # iris
            'PX4_GZ_MODEL_NAME': f'iris_{i}',
            'PX4_SIM_MODEL': 'gazebo-classic_iris',
        }
        px4_cmd = [
            os.path.join(px4_build, 'bin', 'px4'),
            os.path.join(px4_dir, 'ROMFS', 'px4fmu_common'),
            '-s', os.path.join(px4_dir, 'ROMFS', 'px4fmu_common',
                               'init.d-posix', 'rcS'),
            '-i', str(i),
            '-d',
        ]

        actions.append(TimerAction(
            period=4.0 + i * 1.5,
            actions=[ExecuteProcess(
                cmd=px4_cmd,
                output='screen',
                additional_env={
                    **px4_env,
                    'PX4_HOME_LAT': '0.0',
                    'PX4_HOME_LON': '0.0',
                    'PX4_HOME_ALT': '0.0',
                },
                cwd=os.path.join(px4_build, 'tmp', f'rootfs_{i}')
                    if os.path.exists(os.path.join(px4_build, 'tmp'))
                    else px4_build,
            )],
        ))

    # ═══ 4. MAVROS INSTANCES ════════════════════════════
    for i in range(num_drones):
        mavlink_udp_port = 14540 + i

        actions.append(TimerAction(
            period=8.0 + i * 1.0,  # After PX4 stabilizes
            actions=[Node(
                package='mavros',
                executable='mavros_node',
                name=f'mavros_{i}',
                namespace=f'drone_{i}',
                output='screen',
                parameters=[{
                    'fcu_url': f'udp://:{mavlink_udp_port}@localhost:{14557 + i}',
                    'gcs_url': '',
                    'target_system_id': i + 1,
                    'target_component_id': 1,
                    'fcu_protocol': 'v2.0',
                }],
            )],
        ))

    # ═══ 5. PX4-MAVROS BRIDGE ══════════════════════════
    actions.append(TimerAction(
        period=12.0,  # After all MAVROS up
        actions=[Node(
            package='aura_simulation',
            executable='px4_mavros_bridge',
            name='px4_mavros_bridge',
            output='screen',
            parameters=[
                sim_config,
                {'num_drones': num_drones},
            ],
        )],
    ))

    # ═══ 6. A.U.R.A. STACK ═════════════════════════════

    # Dead zone publisher
    actions.append(TimerAction(
        period=13.0,
        actions=[Node(
            package='aura_simulation',
            executable='dead_zone_publisher',
            name='dead_zone_publisher',
            output='screen',
            parameters=[sim_config],
        )],
    ))

    # Network sim
    actions.append(TimerAction(
        period=13.5,
        actions=[Node(
            package='aura_network_sim',
            executable='network_sim_node',
            name='network_sim',
            output='screen',
            parameters=[net_config if os.path.exists(net_config) else sim_config],
        )],
    ))

    # Coverage calculator
    actions.append(TimerAction(
        period=14.0,
        actions=[Node(
            package='aura_network_sim',
            executable='coverage_calculator_node',
            name='coverage_calculator',
            output='screen',
            parameters=[net_config if os.path.exists(net_config) else sim_config],
        )],
    ))

    # Strategic RL
    actions.append(TimerAction(
        period=14.5,
        actions=[Node(
            package='aura_strategic_rl',
            executable='strategic_rl_node',
            name='strategic_rl',
            output='screen',
            parameters=[sim_config],
        )],
    ))

    # Mission control
    actions.append(TimerAction(
        period=15.0,
        actions=[Node(
            package='aura_mission_control',
            executable='mission_control_node',
            name='mission_control',
            output='screen',
            parameters=[mc_config if os.path.exists(mc_config) else sim_config],
        )],
    ))

    return actions
