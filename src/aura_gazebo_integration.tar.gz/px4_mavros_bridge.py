"""
PX4-MAVROS Bridge for A.U.R.A.

Translates between MAVROS topics (per-drone) and A.U.R.A.
SwarmState/CoverageGoal messages. This node replaces
sim_swarm_driver when running with PX4 SITL + Gazebo.

For each drone it:
  - Subscribes to MAVROS local_position, state, battery
  - Aggregates into SwarmState at configured rate
  - Forwards CoverageGoal commands as MAVROS setpoints
  - Handles arming, mode switching, takeoff

Architecture:
  MAVROS/drone_0/* ──┐
  MAVROS/drone_1/* ──┼──► px4_mavros_bridge ──► /swarm/state
  MAVROS/drone_2/* ──┤                      ◄── /coverage/goals
  ...               ──┘
"""

import math
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
import numpy as np
from typing import Dict, Optional
from dataclasses import dataclass, field

from geometry_msgs.msg import PoseStamped, Point, Vector3, Quaternion, TwistStamped
from sensor_msgs.msg import BatteryState, NavSatFix
from mavros_msgs.msg import State as MavrosState
from mavros_msgs.srv import CommandBool, SetMode, CommandTOL
from std_msgs.msg import String

from aura_msgs.msg import (
    DroneState,
    SwarmState,
    CoverageGoal,
    MissionStatus,
)


@dataclass
class PX4Drone:
    """Tracked state of a PX4 drone via MAVROS"""
    drone_id: int
    role: int = 0  # 0=LEAF, 1=HUB

    # From MAVROS
    position: np.ndarray = field(default_factory=lambda: np.zeros(3))
    velocity: np.ndarray = field(default_factory=lambda: np.zeros(3))
    orientation: tuple = (0.0, 0.0, 0.0, 1.0)  # quat
    armed: bool = False
    connected: bool = False
    mode: str = ""
    battery_percent: float = 100.0
    battery_voltage: float = 16.8
    gps_fix: bool = False
    num_satellites: int = 0

    # Goal tracking
    goal_position: Optional[np.ndarray] = None
    sending_setpoints: bool = False


class PX4MavrosBridge(Node):
    """
    Bridges N MAVROS drone instances to the A.U.R.A. topic interface.

    Publishes:
        /swarm/state        (SwarmState)
        /drone_{id}/state   (DroneState) per drone

    Subscribes:
        /coverage/goals     (CoverageGoal) from RL/baseline
        /mission/phase      (String) mission phase transitions

    Per drone subscribes to:
        /drone_{id}/mavros/local_position/pose
        /drone_{id}/mavros/local_position/velocity_body
        /drone_{id}/mavros/state
        /drone_{id}/mavros/battery
        /drone_{id}/mavros/global_position/global
    """

    def __init__(self):
        super().__init__('px4_mavros_bridge')

        # Parameters
        self.declare_parameter('num_drones', 5)
        self.declare_parameter('publish_rate_hz', 10.0)
        self.declare_parameter('hub_drone_id', 0)
        self.declare_parameter('setpoint_rate_hz', 20.0)
        self.declare_parameter('takeoff_altitude_m', 15.0)
        self.declare_parameter('auto_arm', True)

        self.num_drones = self.get_parameter('num_drones').value
        rate = self.get_parameter('publish_rate_hz').value
        hub_id = self.get_parameter('hub_drone_id').value
        self.setpoint_rate = self.get_parameter('setpoint_rate_hz').value
        self.takeoff_alt = self.get_parameter('takeoff_altitude_m').value
        self.auto_arm = self.get_parameter('auto_arm').value

        self.current_phase = 'IDLE'

        # Initialize drone trackers
        self.drones: Dict[int, PX4Drone] = {}
        for i in range(self.num_drones):
            self.drones[i] = PX4Drone(
                drone_id=i,
                role=1 if i == hub_id else 0,
            )

        # QoS
        reliable_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE, depth=10)
        sensor_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT, depth=5)
        mavros_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE, depth=10,
            durability=DurabilityPolicy.VOLATILE)

        # ── A.U.R.A. publishers ───────────────────────────
        self.swarm_pub = self.create_publisher(
            SwarmState, '/swarm/state', reliable_qos)
        self.drone_pubs = {}
        for i in range(self.num_drones):
            self.drone_pubs[i] = self.create_publisher(
                DroneState, f'/drone_{i}/state', reliable_qos)

        # ── A.U.R.A. subscribers ──────────────────────────
        self.create_subscription(
            CoverageGoal, '/coverage/goals',
            self._coverage_goal_cb, reliable_qos)
        self.create_subscription(
            String, '/mission/phase',
            self._phase_cb, reliable_qos)

        # ── Per-drone MAVROS subscribers ──────────────────
        self.setpoint_pubs = {}
        self.arm_clients = {}
        self.mode_clients = {}

        for i in range(self.num_drones):
            ns = f'/drone_{i}/mavros'

            # Position
            self.create_subscription(
                PoseStamped, f'{ns}/local_position/pose',
                lambda msg, idx=i: self._pose_cb(msg, idx),
                sensor_qos)

            # Velocity
            self.create_subscription(
                TwistStamped, f'{ns}/local_position/velocity_body',
                lambda msg, idx=i: self._vel_cb(msg, idx),
                sensor_qos)

            # State (armed, connected, mode)
            self.create_subscription(
                MavrosState, f'{ns}/state',
                lambda msg, idx=i: self._state_cb(msg, idx),
                mavros_qos)

            # Battery
            self.create_subscription(
                BatteryState, f'{ns}/battery',
                lambda msg, idx=i: self._battery_cb(msg, idx),
                sensor_qos)

            # GPS
            self.create_subscription(
                NavSatFix, f'{ns}/global_position/global',
                lambda msg, idx=i: self._gps_cb(msg, idx),
                sensor_qos)

            # Setpoint publisher (for sending goals)
            self.setpoint_pubs[i] = self.create_publisher(
                PoseStamped, f'{ns}/setpoint_position/local',
                reliable_qos)

            # Service clients for arming / mode
            self.arm_clients[i] = self.create_client(
                CommandBool, f'{ns}/cmd/arming')
            self.mode_clients[i] = self.create_client(
                SetMode, f'{ns}/set_mode')

        # ── Timers ────────────────────────────────────────
        self.create_timer(1.0 / rate, self._publish_swarm_state)
        self.create_timer(1.0 / self.setpoint_rate, self._send_setpoints)

        self.get_logger().info(
            f'PX4 MAVROS Bridge initialized for {self.num_drones} drones')

    # ── MAVROS callbacks ─────────────────────────────────

    def _pose_cb(self, msg: PoseStamped, idx: int):
        d = self.drones[idx]
        d.position = np.array([
            msg.pose.position.x,
            msg.pose.position.y,
            msg.pose.position.z,
        ])
        d.orientation = (
            msg.pose.orientation.x,
            msg.pose.orientation.y,
            msg.pose.orientation.z,
            msg.pose.orientation.w,
        )

    def _vel_cb(self, msg: TwistStamped, idx: int):
        d = self.drones[idx]
        d.velocity = np.array([
            msg.twist.linear.x,
            msg.twist.linear.y,
            msg.twist.linear.z,
        ])

    def _state_cb(self, msg: MavrosState, idx: int):
        d = self.drones[idx]
        d.armed = msg.armed
        d.connected = msg.connected
        d.mode = msg.mode

    def _battery_cb(self, msg: BatteryState, idx: int):
        d = self.drones[idx]
        d.battery_percent = msg.percentage * 100.0 if msg.percentage >= 0 else 100.0
        d.battery_voltage = msg.voltage if msg.voltage > 0 else 16.8

    def _gps_cb(self, msg: NavSatFix, idx: int):
        d = self.drones[idx]
        d.gps_fix = msg.status.status >= 0
        # SITL always reports fix

    # ── A.U.R.A. callbacks ───────────────────────────────

    def _coverage_goal_cb(self, msg: CoverageGoal):
        """Forward RL/baseline position commands to MAVROS setpoints"""
        for i, goal in enumerate(msg.goals):
            if i < self.num_drones:
                self.drones[i].goal_position = np.array([
                    goal.x, goal.y, goal.z
                ])
                self.drones[i].sending_setpoints = True

    def _phase_cb(self, msg: String):
        new_phase = msg.data
        if new_phase != self.current_phase:
            self.get_logger().info(f'Phase: {self.current_phase} → {new_phase}')
            self.current_phase = new_phase

            if new_phase == 'PREFLIGHT' and self.auto_arm:
                self._arm_all()
            elif new_phase == 'TAKEOFF':
                self._takeoff_all()
            elif new_phase == 'RTL':
                self._rtl_all()

    # ── Drone commands ───────────────────────────────────

    def _arm_all(self):
        """Arm all drones and set OFFBOARD mode"""
        for i in range(self.num_drones):
            # Must send some setpoints before switching to OFFBOARD
            self.drones[i].goal_position = np.array([
                self.drones[i].position[0],
                self.drones[i].position[1],
                self.drones[i].position[2] + 0.5,
            ])
            self.drones[i].sending_setpoints = True

        # Delay arm/mode switch to allow setpoints to arrive
        self.create_timer(2.0, self._do_arm_sequence, callback_group=None)

    def _do_arm_sequence(self):
        """Actually arm and set OFFBOARD after setpoints flowing"""
        for i in range(self.num_drones):
            # Set OFFBOARD mode
            if self.mode_clients[i].service_is_ready():
                req = SetMode.Request()
                req.custom_mode = 'OFFBOARD'
                self.mode_clients[i].call_async(req)
                self.get_logger().info(f'Drone {i}: OFFBOARD mode requested')

            # Arm
            if self.arm_clients[i].service_is_ready():
                req = CommandBool.Request()
                req.value = True
                self.arm_clients[i].call_async(req)
                self.get_logger().info(f'Drone {i}: Arm requested')

        # Only fire once
        # (ROS 2 doesn't have one-shot timers, so we just let it repeat
        #  but it's harmless to re-arm)

    def _takeoff_all(self):
        """Set takeoff altitude goals"""
        for i in range(self.num_drones):
            d = self.drones[i]
            d.goal_position = np.array([
                d.position[0],
                d.position[1],
                self.takeoff_alt,
            ])
            d.sending_setpoints = True

    def _rtl_all(self):
        """Switch all drones to AUTO.RTL"""
        for i in range(self.num_drones):
            if self.mode_clients[i].service_is_ready():
                req = SetMode.Request()
                req.custom_mode = 'AUTO.RTL'
                self.mode_clients[i].call_async(req)
            self.drones[i].sending_setpoints = False

    # ── Setpoint streaming ───────────────────────────────

    def _send_setpoints(self):
        """Stream setpoints to all drones at high rate (required for OFFBOARD)"""
        for i in range(self.num_drones):
            d = self.drones[i]
            if d.sending_setpoints and d.goal_position is not None:
                msg = PoseStamped()
                msg.header.stamp = self.get_clock().now().to_msg()
                msg.header.frame_id = 'map'
                msg.pose.position.x = float(d.goal_position[0])
                msg.pose.position.y = float(d.goal_position[1])
                msg.pose.position.z = float(d.goal_position[2])
                msg.pose.orientation.w = 1.0  # level flight
                self.setpoint_pubs[i].publish(msg)

    # ── SwarmState publishing ────────────────────────────

    def _publish_swarm_state(self):
        """Aggregate all drone states into SwarmState"""
        msg = SwarmState()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.num_drones = self.num_drones
        msg.mission_phase = self.current_phase

        # Aggregates
        positions = []
        for i in range(self.num_drones):
            d = self.drones[i]
            ds = self._make_drone_state(d)
            msg.drones.append(ds)
            positions.append(d.position)

            # Also publish individual drone state
            self.drone_pubs[i].publish(ds)

        # Swarm-level fields
        msg.avg_signal_strength_dbm = 0.0
        msg.total_throughput_mbps = 0.0
        msg.avg_latency_ms = 0.0
        msg.mesh_connected = False
        msg.backhaul_connected = False

        self.swarm_pub.publish(msg)

    def _make_drone_state(self, d: PX4Drone) -> DroneState:
        ds = DroneState()
        ds.timestamp = self.get_clock().now().to_msg()
        ds.drone_id = d.drone_id
        ds.role = d.role

        ds.position = Point(
            x=float(d.position[0]),
            y=float(d.position[1]),
            z=float(d.position[2]),
        )
        ds.velocity = Vector3(
            x=float(d.velocity[0]),
            y=float(d.velocity[1]),
            z=float(d.velocity[2]),
        )
        ds.orientation = Quaternion(
            x=float(d.orientation[0]),
            y=float(d.orientation[1]),
            z=float(d.orientation[2]),
            w=float(d.orientation[3]),
        )

        # Map PX4 mode to flight_mode enum
        mode_map = {
            'MANUAL': 0, 'STABILIZED': 0,
            'AUTO.TAKEOFF': 1, 'OFFBOARD': 3,
            'AUTO.LOITER': 2, 'AUTO.MISSION': 3,
            'AUTO.RTL': 4, 'AUTO.LAND': 5,
        }
        ds.flight_mode = mode_map.get(d.mode, 0)

        ds.battery_percent = float(d.battery_percent)
        ds.battery_voltage = float(d.battery_voltage)
        ds.signal_strength_dbm = -65.0  # network_sim computes real values
        ds.gps_fix = d.gps_fix
        ds.num_satellites = 12  # SITL default
        ds.throughput_mbps = 0.0
        ds.latency_ms = 0.0
        ds.connected_neighbors = 0

        return ds


def main(args=None):
    rclpy.init(args=args)
    node = PX4MavrosBridge()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.get_logger().info("PX4 MAVROS Bridge shutting down")
        node.destroy_node()
        try:
            rclpy.shutdown()
        except Exception:
            pass


if __name__ == '__main__':
    main()
