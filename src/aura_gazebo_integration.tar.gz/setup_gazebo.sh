#!/bin/bash
# ═══════════════════════════════════════════════════════════
# A.U.R.A. Gazebo Integration Setup
# ═══════════════════════════════════════════════════════════
# Run this inside your Docker container (aura-dev):
#   bash setup_gazebo.sh
#
# What it does:
#   1. Installs MAVROS if missing
#   2. Copies earthquake world to ~/ws/worlds/
#   3. Copies launch file to aura_simulation package
#   4. Copies px4_mavros_bridge node to aura_simulation
#   5. Registers new entry point and rebuilds
# ═══════════════════════════════════════════════════════════

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WS=~/ws

echo "═══ A.U.R.A. Gazebo Integration Setup ═══"
echo ""

# ── 1. Source ROS ─────────────────────────────────────────
echo "[1/6] Sourcing ROS 2..."
source /opt/ros/humble/setup.bash
if [ -f $WS/install/setup.bash ]; then
    source $WS/install/setup.bash
fi

# ── 2. Install MAVROS ────────────────────────────────────
echo "[2/6] Checking MAVROS..."
if ! ros2 pkg list 2>/dev/null | grep -q mavros; then
    echo "  Installing MAVROS..."
    sudo apt-get update -qq
    sudo apt-get install -y -qq \
        ros-humble-mavros \
        ros-humble-mavros-extras \
        ros-humble-mavros-msgs
    echo "  Installing GeographicLib datasets..."
    sudo /opt/ros/humble/lib/mavros/install_geographiclib_datasets.sh
    echo "  MAVROS installed."
else
    echo "  MAVROS already installed."
fi

# ── 3. Copy world file ──────────────────────────────────
echo "[3/6] Installing earthquake world..."
mkdir -p $WS/worlds
cp "$SCRIPT_DIR/earthquake_city.world" $WS/worlds/earthquake_city.world
echo "  Copied to $WS/worlds/earthquake_city.world"

# ── 4. Copy launch file ─────────────────────────────────
echo "[4/6] Installing Gazebo launch file..."
LAUNCH_DIR=$WS/src/aura_simulation/launch
mkdir -p "$LAUNCH_DIR"
cp "$SCRIPT_DIR/gazebo_swarm.launch.py" "$LAUNCH_DIR/gazebo_swarm.launch.py"
echo "  Copied to $LAUNCH_DIR/gazebo_swarm.launch.py"

# ── 5. Copy bridge node ─────────────────────────────────
echo "[5/6] Installing PX4-MAVROS bridge..."
BRIDGE_DIR=$WS/src/aura_simulation/aura_simulation
cp "$SCRIPT_DIR/px4_mavros_bridge.py" "$BRIDGE_DIR/px4_mavros_bridge.py"
echo "  Copied to $BRIDGE_DIR/px4_mavros_bridge.py"

# Add entry point if not present
SETUP_PY=$WS/src/aura_simulation/setup.py
if ! grep -q "px4_mavros_bridge" "$SETUP_PY" 2>/dev/null; then
    echo "  Adding px4_mavros_bridge entry point..."
    sed -i "s|'scenario_runner = aura_simulation.scenario_runner:main',|'scenario_runner = aura_simulation.scenario_runner:main',\n            'px4_mavros_bridge = aura_simulation.px4_mavros_bridge:main',|" "$SETUP_PY"
    echo "  Entry point added."
else
    echo "  Entry point already exists."
fi

# Add launch files to data_files in setup.py if not there
if ! grep -q "gazebo_swarm" "$SETUP_PY" 2>/dev/null; then
    echo "  Ensuring launch files are in data_files..."
    # The launch dir should already be included from sim_no_px4.launch.py
fi

# ── 6. Build ─────────────────────────────────────────────
echo "[6/6] Building aura_simulation..."
cd $WS
colcon build --packages-select aura_simulation 2>&1 | tail -5
source install/setup.bash

echo ""
echo "═══ Setup Complete ═══"
echo ""
echo "To verify Gazebo world:"
echo "  gzserver ~/ws/worlds/earthquake_city.world --verbose &"
echo "  gzclient"
echo ""
echo "To run single PX4 drone test:"
echo "  cd ~/PX4-Autopilot"
echo "  HEADLESS=1 make px4_sitl gazebo-classic_iris"
echo ""
echo "To launch full A.U.R.A. + Gazebo stack:"
echo "  ros2 launch aura_simulation gazebo_swarm.launch.py"
echo ""
echo "To launch headless (no GUI):"
echo "  ros2 launch aura_simulation gazebo_swarm.launch.py headless:=true"
echo ""
