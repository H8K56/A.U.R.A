"""
A.U.R.A. Gazebo + PX4 SITL Launch (v2)

Uses PX4's own sitl_multiple_run.sh for multi-drone spawning,
then layers MAVROS bridges and the A.U.R.A. stack on top.

Usage:
    ros2 launch aura_simulation gazebo_swarm.launch.py
    ros2 launch aura_simulation gazebo_swarm.launch.py num_drones:=3
    ros2 launch aura_simulation gazebo_swarm.launch.py world:=earthquake_city

Prerequisites:
    sudo apt install ros-humble-mavros ros-humble-mavros-extras
    sudo /opt/ros/humble/lib/mavros/install_geographiclib_datasets.sh
"""

import os
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    ExecuteProcess,
    TimerAction,
    OpaqueFunction,
)
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('num_drones', default_value='5'),
        DeclareLaunchArgument('world', default_value='earthquake_city'),
        DeclareLaunchArgument('auto_start', default_value='true'),
        DeclareLaunchArgument('inject_dead_zone', default_value='false'),
        DeclareLaunchArgument('use_baseline', default_value='true'),
        OpaqueFunction(function=launch_setup),
    ])


def launch_setup(context, *args, **kwargs):
    num_drones = int(context.launch_configurations.get('num_drones', '5'))
    world = context.launch_configurations.get('world', 'earthquake_city')

    px4_dir = os.path.expanduser('~/PX4-Autopilot')
    px4_worlds = os.path.join(
        px4_dir, 'Tools', 'simulation', 'gazebo-classic',
        'sitl_gazebo-classic', 'worlds')
    multi_script = os.path.join(
        px4_dir, 'Tools', 'simulation', 'gazebo-classic',
        'sitl_multiple_run.sh')

    # Symlink earthquake world into PX4 worlds directory if needed
    aura_world = os.path.expanduser(f'~/ws/worlds/{world}.world')
    px4_world = os.path.join(px4_worlds, f'{world}.world')
    if os.path.exists(aura_world) and not os.path.exists(px4_world):
        try:
            os.symlink(aura_world, px4_world)
        except OSError:
            pass  # Already exists or permission issue

    # Package configs
    def _cfg(pkg_name, config_name):
        try:
            d = get_package_share_directory(pkg_name)
            p = os.path.join(d, 'config', config_name)
            if os.path.exists(p):
                return p
        except Exception:
            pass
        fallback = os.path.expanduser('~/ws/config/sim_params.yaml')
        return fallback if os.path.exists(fallback) else ''

    sim_config = _cfg('aura_simulation', 'sim_params.yaml')
    net_config = _cfg('aura_network_sim', 'network_sim_params.yaml')
    mc_config = _cfg('aura_mission_control', 'mission_control_params.yaml')

    actions = []

    # ═══ 1. PX4 MULTI-DRONE (their script) ═════════════
    #
    # sitl_multiple_run.sh handles everything:
    #   - sources setup_gazebo.bash (GAZEBO_PLUGIN_PATH etc.)
    #   - launches gzserver with the world
    #   - generates per-instance SDF via jinja (unique ports)
    #   - spawns iris models into Gazebo
    #   - launches PX4 -i N with correct working dirs
    #   - launches gzclient at the end
    #
    # Port scheme (from the script, 1-based instance IDs):
    #   Instance N: TCP 4560+N, UDP 14560+N

    actions.append(ExecuteProcess(
        cmd=[
            'bash', multi_script,
            '-n', str(num_drones),
            '-m', 'iris',
            '-w', world,
        ],
        output='screen',
        additional_env={
            'ROS_VERSION': '2',
            'PX4_HOME_LAT': '0.0',
            'PX4_HOME_LON': '0.0',
            'PX4_HOME_ALT': '0.0',
        },
    ))

    # ═══ 2. MAVROS BRIDGES ═════════════════════════════
    #
    # PX4's script uses 1-based instance IDs.
    # Each PX4 instance with `-i N` (1-based) communicates on:
    #   Simulator MAVLink TCP: 4560 + N
    #   Outgoing UDP:          14560 + N
    #
    # For MAVROS, the safest connection is TCP to the
    # simulator_mavlink port, since UDP port allocation
    # varies by PX4 version. TCP is deterministic.
    #
    # fcu_url format: tcp://localhost:<port>

    for i in range(num_drones):
        instance_id = i + 1  # 1-based, matches the script
        tcp_port = 4560 + instance_id

        actions.append(TimerAction(
            period=15.0 + i * 2.0,
            actions=[Node(
                package='mavros',
                executable='mavros_node',
                name=f'mavros_{i}',
                namespace=f'drone_{i}',
                output='screen',
                parameters=[{
                    'fcu_url': f'tcp://localhost:{tcp_port}',
                    'gcs_url': '',
                    'target_system_id': instance_id,
                    'target_component_id': 1,
                    'fcu_protocol': 'v2.0',
                }],
            )],
        ))

    # ═══ 3. PX4-MAVROS BRIDGE ══════════════════════════
    bridge_start = 20.0 + num_drones * 2.0
    actions.append(TimerAction(
        period=bridge_start,
        actions=[Node(
            package='aura_simulation',
            executable='px4_mavros_bridge',
            name='px4_mavros_bridge',
            output='screen',
            parameters=[
                sim_config,
                {'num_drones': num_drones},
            ],
        )],
    ))

    # ═══ 4. A.U.R.A. STACK ═════════════════════════════
    aura_start = bridge_start + 3.0

    aura_nodes = [
        ('aura_simulation', 'dead_zone_publisher', 'dead_zone_publisher', sim_config, 0.0),
        ('aura_network_sim', 'network_sim_node', 'network_sim', net_config, 0.5),
        ('aura_network_sim', 'coverage_calculator_node', 'coverage_calculator', net_config, 1.0),
        ('aura_strategic_rl', 'strategic_rl_node', 'strategic_rl', sim_config, 1.5),
        ('aura_mission_control', 'mission_control_node', 'mission_control', mc_config, 2.0),
    ]

    for pkg, exe, name, cfg, offset in aura_nodes:
        actions.append(TimerAction(
            period=aura_start + offset,
            actions=[Node(
                package=pkg,
                executable=exe,
                name=name,
                output='screen',
                parameters=[cfg] if cfg else [],
            )],
        ))

    return actions
