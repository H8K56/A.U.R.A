"""
A.U.R.A. Network Simulation Package

Provides NS-3 based network simulation for disaster relief UAV swarm.
Simulates WiFi mesh network between drones and coverage to ground users.
"""

__version__ = '0.1.0'
