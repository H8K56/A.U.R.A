#!/usr/bin/env python3
"""
Coverage Calculator Node

Standalone node for computing and visualizing network coverage.
Subscribes to NetworkMetrics and publishes coverage statistics.
"""

import rclpy
from rclpy.node import Node
import numpy as np

from aura_msgs.msg import NetworkMetrics, CoverageMap
from geometry_msgs.msg import Point


class CoverageCalculatorNode(Node):
    """
    Processes network metrics and computes coverage statistics.
    """
    
    def __init__(self):
        super().__init__('coverage_calculator')
        
        # Parameters
        self.declare_parameter('priority_zones', [])  # List of (x, y, radius, weight)
        self.declare_parameter('target_coverage_percent', 80.0)
        
        self.target_coverage = self.get_parameter('target_coverage_percent').value
        
        # State
        self.latest_metrics: NetworkMetrics = None
        self.priority_zones = []
        
        # Subscribers
        self.metrics_sub = self.create_subscription(
            NetworkMetrics, '/network/metrics',
            self.metrics_callback, 10
        )
        
        # Publishers
        self.coverage_map_pub = self.create_publisher(
            CoverageMap, '/network/coverage_map', 10
        )
        
        # Timer for periodic stats
        self.stats_timer = self.create_timer(5.0, self.log_stats)
        
        self.get_logger().info('Coverage calculator started')
    
    def metrics_callback(self, msg: NetworkMetrics):
        """Process network metrics and compute coverage map"""
        self.latest_metrics = msg
        
        # Build coverage map message
        coverage_msg = CoverageMap()
        coverage_msg.timestamp = msg.timestamp
        coverage_msg.grid_size_x = msg.grid_size_x
        coverage_msg.grid_size_y = msg.grid_size_y
        coverage_msg.cell_size_meters = msg.cell_size_meters
        coverage_msg.origin = msg.origin
        
        # Copy coverage data
        coverage_msg.is_covered = msg.coverage_mask
        
        # Compute demand level (simplified - uniform for now)
        num_cells = msg.grid_size_x * msg.grid_size_y
        coverage_msg.demand_level = [1.0] * num_cells
        
        # Compute coverage quality (normalized signal strength)
        if msg.signal_strength_dbm:
            max_rssi = -50.0  # Excellent signal
            min_rssi = -90.0  # Poor signal
            quality = []
            for rssi in msg.signal_strength_dbm:
                q = (rssi - min_rssi) / (max_rssi - min_rssi)
                quality.append(max(0.0, min(1.0, q)))
            coverage_msg.coverage_quality = quality
        
        # Target area (all cells for now)
        coverage_msg.is_target = [True] * num_cells
        
        self.coverage_map_pub.publish(coverage_msg)
    
    def log_stats(self):
        """Log coverage statistics periodically"""
        if self.latest_metrics is None:
            return
        
        msg = self.latest_metrics
        
        self.get_logger().info(
            f'Coverage: {msg.total_coverage_percent:.1f}% | '
            f'Avg Signal: {msg.avg_signal_strength_dbm:.1f} dBm | '
            f'Avg Throughput: {msg.avg_throughput_mbps:.1f} Mbps'
        )
        
        # Check against target
        if msg.total_coverage_percent < self.target_coverage:
            deficit = self.target_coverage - msg.total_coverage_percent
            self.get_logger().warn(
                f'Coverage below target! Deficit: {deficit:.1f}%'
            )
    
    def add_priority_zone(self, x: float, y: float, radius: float, weight: float):
        """Add a priority zone (e.g., hospital, rescue staging area)"""
        self.priority_zones.append({
            'center': np.array([x, y]),
            'radius': radius,
            'weight': weight
        })


def main(args=None):
    rclpy.init(args=args)
    node = CoverageCalculatorNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
