#!/usr/bin/env python3
"""
NS-3 Network Simulation Node

Bridges NS-3 network simulation with ROS 2 for A.U.R.A. swarm.
Simulates:
- WiFi mesh network between drones
- Coverage to ground users
- Signal propagation with weather effects
"""

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy

import numpy as np
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field
import threading
import time

from geometry_msgs.msg import Point
from aura_msgs.msg import DroneState, SwarmState, NetworkMetrics, WeatherZone


@dataclass
class DroneNetworkState:
    """Network state for a single drone"""
    drone_id: int
    position: np.ndarray  # [x, y, z] in meters
    is_hub: bool = False
    tx_power_dbm: float = 20.0
    
    # Computed metrics
    connected_neighbors: List[int] = field(default_factory=list)
    throughput_mbps: float = 0.0
    latency_ms: float = 0.0
    signal_strength_dbm: float = -100.0


@dataclass 
class NetworkConfig:
    """Network simulation configuration"""
    # WiFi parameters
    frequency_ghz: float = 2.4
    bandwidth_mhz: float = 20.0
    tx_power_dbm: float = 20.0
    rx_sensitivity_dbm: float = -85.0
    noise_floor_dbm: float = -95.0
    
    # Propagation model (log-distance)
    path_loss_exponent: float = 2.5  # Free space = 2.0, urban = 3.5
    reference_loss_db: float = 40.0  # Loss at 1 meter
    shadow_std_db: float = 4.0  # Log-normal shadowing
    
    # Mesh parameters
    max_mesh_neighbors: int = 4
    mesh_routing_overhead: float = 0.1  # 10% overhead
    
    # Coverage grid
    grid_resolution_m: float = 10.0
    coverage_threshold_dbm: float = -80.0
    
    # Data rates (simplified)
    max_data_rate_mbps: float = 54.0  # 802.11g
    min_data_rate_mbps: float = 6.0


class PropagationModel:
    """
    Radio propagation model for UAV-to-UAV and UAV-to-ground links.
    Uses log-distance path loss with weather effects.
    """
    
    def __init__(self, config: NetworkConfig):
        self.config = config
        self.rng = np.random.default_rng()
        
    def compute_path_loss(self, distance_m: float, 
                          weather_attenuation_db: float = 0.0) -> float:
        """
        Compute path loss using log-distance model.
        
        PL(d) = PL(d0) + 10 * n * log10(d/d0) + X_sigma + weather
        """
        if distance_m < 1.0:
            distance_m = 1.0
            
        # Log-distance path loss
        path_loss = (self.config.reference_loss_db + 
                     10 * self.config.path_loss_exponent * np.log10(distance_m))
        
        # Add shadowing (could cache for consistent values)
        shadowing = self.rng.normal(0, self.config.shadow_std_db)
        
        # Add weather attenuation (rain, etc.)
        path_loss += weather_attenuation_db + shadowing
        
        return path_loss
    
    def compute_rssi(self, tx_power_dbm: float, distance_m: float,
                     weather_attenuation_db: float = 0.0) -> float:
        """Compute received signal strength"""
        path_loss = self.compute_path_loss(distance_m, weather_attenuation_db)
        return tx_power_dbm - path_loss
    
    def compute_snr(self, rssi_dbm: float) -> float:
        """Compute signal-to-noise ratio"""
        return rssi_dbm - self.config.noise_floor_dbm
    
    def compute_data_rate(self, snr_db: float) -> float:
        """
        Estimate achievable data rate from SNR.
        Simplified model based on 802.11 rate adaptation.
        """
        if snr_db < 4:
            return 0.0
        elif snr_db < 8:
            return self.config.min_data_rate_mbps
        elif snr_db < 12:
            return 12.0
        elif snr_db < 16:
            return 24.0
        elif snr_db < 20:
            return 36.0
        else:
            return self.config.max_data_rate_mbps


class MeshNetworkSimulator:
    """
    Simulates WiFi mesh network between drones.
    Computes connectivity, throughput, and latency.
    """
    
    def __init__(self, config: NetworkConfig):
        self.config = config
        self.propagation = PropagationModel(config)
        self.drones: Dict[int, DroneNetworkState] = {}
        self.link_matrix: Optional[np.ndarray] = None  # Adjacency matrix
        self.rssi_matrix: Optional[np.ndarray] = None  # Signal strength matrix
        
    def update_drone(self, drone_id: int, position: np.ndarray, is_hub: bool = False):
        """Update drone position in simulation"""
        if drone_id not in self.drones:
            self.drones[drone_id] = DroneNetworkState(
                drone_id=drone_id,
                position=position,
                is_hub=is_hub
            )
        else:
            self.drones[drone_id].position = position
            self.drones[drone_id].is_hub = is_hub
    
    def remove_drone(self, drone_id: int):
        """Remove drone from simulation"""
        if drone_id in self.drones:
            del self.drones[drone_id]
    
    def compute_link_quality(self, weather_zones: List[WeatherZone] = None) -> None:
        """
        Compute all link qualities between drones.
        Updates link_matrix and rssi_matrix.
        """
        n = len(self.drones)
        if n == 0:
            return
            
        drone_ids = sorted(self.drones.keys())
        id_to_idx = {did: i for i, did in enumerate(drone_ids)}
        
        self.link_matrix = np.zeros((n, n), dtype=bool)
        self.rssi_matrix = np.full((n, n), -200.0)  # Very low default
        
        for i, id_i in enumerate(drone_ids):
            drone_i = self.drones[id_i]
            for j, id_j in enumerate(drone_ids):
                if i >= j:
                    continue
                    
                drone_j = self.drones[id_j]
                distance = np.linalg.norm(drone_i.position - drone_j.position)
                
                # Compute weather attenuation along path
                weather_atten = self._compute_weather_attenuation(
                    drone_i.position, drone_j.position, weather_zones or []
                )
                
                rssi = self.propagation.compute_rssi(
                    drone_i.tx_power_dbm, distance, weather_atten
                )
                
                self.rssi_matrix[i, j] = rssi
                self.rssi_matrix[j, i] = rssi
                
                # Link exists if RSSI above threshold
                if rssi > self.config.rx_sensitivity_dbm:
                    self.link_matrix[i, j] = True
                    self.link_matrix[j, i] = True
        
        # Update drone states with connectivity info
        for i, drone_id in enumerate(drone_ids):
            drone = self.drones[drone_id]
            neighbors = []
            best_rssi = -200.0
            
            for j, other_id in enumerate(drone_ids):
                if self.link_matrix[i, j]:
                    neighbors.append(other_id)
                    best_rssi = max(best_rssi, self.rssi_matrix[i, j])
            
            drone.connected_neighbors = neighbors[:self.config.max_mesh_neighbors]
            drone.signal_strength_dbm = best_rssi
    
    def _compute_weather_attenuation(self, pos1: np.ndarray, pos2: np.ndarray,
                                      weather_zones: List[WeatherZone]) -> float:
        """Compute total weather attenuation along a path"""
        total_atten = 0.0
        
        for zone in weather_zones:
            if not zone.is_active:
                continue
                
            # Simplified: check if midpoint is in zone
            midpoint = (pos1 + pos2) / 2
            center = np.array([zone.center.x, zone.center.y, zone.center.z])
            dist_to_zone = np.linalg.norm(midpoint[:2] - center[:2])
            
            if dist_to_zone < zone.radius_meters:
                total_atten += zone.signal_attenuation_db
        
        return total_atten
    
    def compute_mesh_metrics(self) -> Dict[int, Tuple[float, float]]:
        """
        Compute throughput and latency for each drone in the mesh.
        Returns dict of {drone_id: (throughput_mbps, latency_ms)}
        """
        metrics = {}
        
        if not self.drones or self.rssi_matrix is None:
            return metrics
        
        drone_ids = sorted(self.drones.keys())
        
        for i, drone_id in enumerate(drone_ids):
            drone = self.drones[drone_id]
            
            if not drone.connected_neighbors:
                metrics[drone_id] = (0.0, 999.0)
                continue
            
            # Compute average link quality to neighbors
            total_rate = 0.0
            for neighbor_id in drone.connected_neighbors:
                j = drone_ids.index(neighbor_id)
                rssi = self.rssi_matrix[i, j]
                snr = self.propagation.compute_snr(rssi)
                rate = self.propagation.compute_data_rate(snr)
                total_rate += rate
            
            # Average rate, accounting for mesh overhead
            avg_rate = total_rate / len(drone.connected_neighbors)
            effective_rate = avg_rate * (1 - self.config.mesh_routing_overhead)
            
            # Estimate latency (simplified)
            # Base latency + hop delay based on mesh depth
            base_latency_ms = 2.0
            hop_latency_ms = 5.0
            num_hops = self._estimate_hops_to_hub(drone_id)
            latency = base_latency_ms + num_hops * hop_latency_ms
            
            metrics[drone_id] = (effective_rate, latency)
            drone.throughput_mbps = effective_rate
            drone.latency_ms = latency
        
        return metrics
    
    def _estimate_hops_to_hub(self, drone_id: int) -> int:
        """Estimate number of hops to nearest hub drone"""
        # Simple BFS to find hub
        if self.drones[drone_id].is_hub:
            return 0
            
        visited = {drone_id}
        queue = [(drone_id, 0)]
        
        while queue:
            current_id, hops = queue.pop(0)
            
            for neighbor_id in self.drones.get(current_id, DroneNetworkState(0, np.zeros(3))).connected_neighbors:
                if neighbor_id in visited:
                    continue
                    
                if self.drones.get(neighbor_id, DroneNetworkState(0, np.zeros(3))).is_hub:
                    return hops + 1
                    
                visited.add(neighbor_id)
                queue.append((neighbor_id, hops + 1))
        
        return 10  # No path to hub
    
    def is_mesh_connected(self) -> bool:
        """Check if all drones form a connected mesh"""
        if len(self.drones) <= 1:
            return True
            
        if self.link_matrix is None:
            return False
            
        # BFS from first drone
        drone_ids = sorted(self.drones.keys())
        visited = {drone_ids[0]}
        queue = [0]
        
        while queue:
            i = queue.pop(0)
            for j in range(len(drone_ids)):
                if j not in visited and self.link_matrix[i, j]:
                    visited.add(j)
                    queue.append(j)
        
        return len(visited) == len(drone_ids)


class CoverageCalculator:
    """
    Calculates ground coverage from UAV positions.
    Produces a grid map of signal strength and data rate.
    """
    
    def __init__(self, config: NetworkConfig, 
                 area_bounds: Tuple[float, float, float, float]):
        """
        Args:
            config: Network configuration
            area_bounds: (x_min, y_min, x_max, y_max) in meters
        """
        self.config = config
        self.propagation = PropagationModel(config)
        self.bounds = area_bounds
        
        # Create coverage grid
        x_min, y_min, x_max, y_max = area_bounds
        self.grid_x = np.arange(x_min, x_max, config.grid_resolution_m)
        self.grid_y = np.arange(y_min, y_max, config.grid_resolution_m)
        self.grid_size_x = len(self.grid_x)
        self.grid_size_y = len(self.grid_y)
        
        # Coverage maps
        self.signal_strength = np.full((self.grid_size_y, self.grid_size_x), -200.0)
        self.throughput = np.zeros((self.grid_size_y, self.grid_size_x))
        self.coverage_mask = np.zeros((self.grid_size_y, self.grid_size_x), dtype=bool)
    
    def compute_coverage(self, drones: Dict[int, DroneNetworkState],
                         weather_zones: List[WeatherZone] = None,
                         ground_height: float = 0.0) -> None:
        """
        Compute coverage map from current drone positions.
        """
        self.signal_strength.fill(-200.0)
        self.throughput.fill(0.0)
        self.coverage_mask.fill(False)
        
        if not drones:
            return
        
        for iy, y in enumerate(self.grid_y):
            for ix, x in enumerate(self.grid_x):
                ground_pos = np.array([x, y, ground_height])
                
                best_rssi = -200.0
                best_rate = 0.0
                
                # Find best serving drone
                for drone in drones.values():
                    distance = np.linalg.norm(ground_pos - drone.position)
                    
                    # Weather attenuation
                    weather_atten = 0.0
                    if weather_zones:
                        for zone in weather_zones:
                            if not zone.is_active:
                                continue
                            center = np.array([zone.center.x, zone.center.y, zone.center.z])
                            if np.linalg.norm(ground_pos[:2] - center[:2]) < zone.radius_meters:
                                weather_atten += zone.signal_attenuation_db
                    
                    rssi = self.propagation.compute_rssi(
                        drone.tx_power_dbm, distance, weather_atten
                    )
                    
                    if rssi > best_rssi:
                        best_rssi = rssi
                        snr = self.propagation.compute_snr(rssi)
                        best_rate = self.propagation.compute_data_rate(snr)
                
                self.signal_strength[iy, ix] = best_rssi
                self.throughput[iy, ix] = best_rate
                self.coverage_mask[iy, ix] = best_rssi > self.config.coverage_threshold_dbm
    
    def get_coverage_percent(self) -> float:
        """Get percentage of area with coverage"""
        return 100.0 * np.mean(self.coverage_mask)
    
    def get_average_signal(self) -> float:
        """Get average signal strength in covered areas"""
        if not np.any(self.coverage_mask):
            return -200.0
        return float(np.mean(self.signal_strength[self.coverage_mask]))
    
    def get_average_throughput(self) -> float:
        """Get average throughput in covered areas"""
        if not np.any(self.coverage_mask):
            return 0.0
        return float(np.mean(self.throughput[self.coverage_mask]))


class NetworkSimNode(Node):
    """
    ROS 2 node for network simulation.
    """
    
    def __init__(self):
        super().__init__('network_sim')
        
        # Parameters
        self.declare_parameter('update_rate_hz', 10.0)
        self.declare_parameter('area_x_min', -100.0)
        self.declare_parameter('area_x_max', 100.0)
        self.declare_parameter('area_y_min', -100.0)
        self.declare_parameter('area_y_max', 100.0)
        self.declare_parameter('grid_resolution', 10.0)
        self.declare_parameter('hub_drone_id', 0)
        
        update_rate = self.get_parameter('update_rate_hz').value
        x_min = self.get_parameter('area_x_min').value
        x_max = self.get_parameter('area_x_max').value
        y_min = self.get_parameter('area_y_min').value
        y_max = self.get_parameter('area_y_max').value
        grid_res = self.get_parameter('grid_resolution').value
        self.hub_id = self.get_parameter('hub_drone_id').value
        
        # Network configuration
        self.config = NetworkConfig(grid_resolution_m=grid_res)
        
        # Simulators
        self.mesh_sim = MeshNetworkSimulator(self.config)
        self.coverage_calc = CoverageCalculator(
            self.config, 
            (x_min, y_min, x_max, y_max)
        )
        
        # Weather zones
        self.weather_zones: List[WeatherZone] = []
        
        # Subscribers
        self.swarm_state_sub = self.create_subscription(
            SwarmState, '/swarm/state', self.swarm_state_callback, 10)
        
        self.weather_sub = self.create_subscription(
            WeatherZone, '/weather/zones', self.weather_callback, 10)
        
        # Publishers
        self.metrics_pub = self.create_publisher(
            NetworkMetrics, '/network/metrics', 10)
        
        # Timer
        self.update_timer = self.create_timer(
            1.0 / update_rate, self.update_callback)
        
        self.get_logger().info('Network simulation node started')
    
    def swarm_state_callback(self, msg: SwarmState):
        """Update drone positions from swarm state"""
        for drone in msg.drones:
            pos = np.array([
                drone.position.x,
                drone.position.y, 
                drone.position.z
            ])
            is_hub = (drone.drone_id == self.hub_id or 
                      drone.role == DroneState.ROLE_HUB)
            
            self.mesh_sim.update_drone(drone.drone_id, pos, is_hub)
    
    def weather_callback(self, msg: WeatherZone):
        """Update weather zones"""
        # Find and update or add zone
        for i, zone in enumerate(self.weather_zones):
            if zone.zone_id == msg.zone_id:
                self.weather_zones[i] = msg
                return
        self.weather_zones.append(msg)
    
    def update_callback(self):
        """Periodic network simulation update"""
        # Compute mesh connectivity
        self.mesh_sim.compute_link_quality(self.weather_zones)
        mesh_metrics = self.mesh_sim.compute_mesh_metrics()
        
        # Compute ground coverage
        self.coverage_calc.compute_coverage(
            self.mesh_sim.drones, 
            self.weather_zones
        )
        
        # Build and publish metrics message
        msg = NetworkMetrics()
        msg.timestamp = self.get_clock().now().to_msg()
        
        # Grid info
        msg.grid_size_x = self.coverage_calc.grid_size_x
        msg.grid_size_y = self.coverage_calc.grid_size_y
        msg.cell_size_meters = self.config.grid_resolution_m
        msg.origin.x = float(self.coverage_calc.bounds[0])
        msg.origin.y = float(self.coverage_calc.bounds[1])
        msg.origin.z = 0.0
        
        # Flatten coverage grids
        msg.signal_strength_dbm = self.coverage_calc.signal_strength.flatten().tolist()
        msg.throughput_mbps = self.coverage_calc.throughput.flatten().tolist()
        msg.coverage_mask = self.coverage_calc.coverage_mask.flatten().tolist()
        
        # Aggregate metrics
        msg.total_coverage_percent = self.coverage_calc.get_coverage_percent()
        msg.avg_signal_strength_dbm = self.coverage_calc.get_average_signal()
        msg.avg_throughput_mbps = self.coverage_calc.get_average_throughput()
        
        # Per-link metrics
        drone_ids = sorted(self.mesh_sim.drones.keys())
        for i, id_i in enumerate(drone_ids):
            for j, id_j in enumerate(drone_ids):
                if j <= i:
                    continue
                if self.mesh_sim.link_matrix is not None and self.mesh_sim.link_matrix[i, j]:
                    msg.link_from_drone.append(id_i)
                    msg.link_to_drone.append(id_j)
                    
                    rssi = self.mesh_sim.rssi_matrix[i, j]
                    snr = self.mesh_sim.propagation.compute_snr(rssi)
                    rate = self.mesh_sim.propagation.compute_data_rate(snr)
                    
                    msg.link_throughput_mbps.append(rate)
                    msg.link_rssi_dbm.append(rssi)
                    msg.link_latency_ms.append(5.0)  # Simplified
        
        # Mesh status
        msg.backhaul_active = any(d.is_hub for d in self.mesh_sim.drones.values())
        
        if mesh_metrics:
            avg_throughput = np.mean([m[0] for m in mesh_metrics.values()])
            avg_latency = np.mean([m[1] for m in mesh_metrics.values()])
            msg.avg_throughput_mbps = avg_throughput
            msg.avg_latency_ms = avg_latency
        
        self.metrics_pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = NetworkSimNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
