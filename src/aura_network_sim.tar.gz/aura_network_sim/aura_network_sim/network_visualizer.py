#!/usr/bin/env python3
"""
Network Visualizer Node

Provides terminal-based visualization of network state.
Uses rich library for fancy TUI output.
"""

import rclpy
from rclpy.node import Node
import numpy as np
from typing import Dict, List

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.layout import Layout
    from rich.live import Live
    from rich.text import Text
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False

from aura_msgs.msg import NetworkMetrics, SwarmState, DroneState


class NetworkVisualizerNode(Node):
    """
    Visualizes network metrics in terminal using rich.
    """
    
    def __init__(self):
        super().__init__('network_visualizer')
        
        self.declare_parameter('update_rate_hz', 2.0)
        update_rate = self.get_parameter('update_rate_hz').value
        
        # State
        self.latest_metrics: NetworkMetrics = None
        self.latest_swarm: SwarmState = None
        self.drone_metrics: Dict[int, dict] = {}
        
        # Subscribers
        self.metrics_sub = self.create_subscription(
            NetworkMetrics, '/network/metrics',
            self.metrics_callback, 10
        )
        
        self.swarm_sub = self.create_subscription(
            SwarmState, '/swarm/state',
            self.swarm_callback, 10
        )
        
        # Visualization
        if RICH_AVAILABLE:
            self.console = Console()
            self.timer = self.create_timer(1.0 / update_rate, self.render)
        else:
            self.get_logger().warn('rich library not available, using simple output')
            self.timer = self.create_timer(2.0, self.simple_render)
        
        self.get_logger().info('Network visualizer started')
    
    def metrics_callback(self, msg: NetworkMetrics):
        self.latest_metrics = msg
        
        # Build per-link map
        for i in range(len(msg.link_from_drone)):
            from_id = msg.link_from_drone[i]
            to_id = msg.link_to_drone[i]
            
            if from_id not in self.drone_metrics:
                self.drone_metrics[from_id] = {'links': []}
            if to_id not in self.drone_metrics:
                self.drone_metrics[to_id] = {'links': []}
            
            link_info = {
                'peer': to_id,
                'rssi': msg.link_rssi_dbm[i] if i < len(msg.link_rssi_dbm) else -100,
                'throughput': msg.link_throughput_mbps[i] if i < len(msg.link_throughput_mbps) else 0,
            }
            self.drone_metrics[from_id]['links'].append(link_info)
    
    def swarm_callback(self, msg: SwarmState):
        self.latest_swarm = msg
    
    def render(self):
        """Render network state using rich"""
        if not RICH_AVAILABLE:
            return
        
        self.console.clear()
        
        # Header
        self.console.print(Panel.fit(
            "[bold cyan]A.U.R.A. Network Monitor[/bold cyan]",
            border_style="cyan"
        ))
        
        # Coverage stats
        if self.latest_metrics:
            m = self.latest_metrics
            stats_table = Table(show_header=False, box=None)
            stats_table.add_column("Metric", style="cyan")
            stats_table.add_column("Value", style="green")
            
            stats_table.add_row("Coverage", f"{m.total_coverage_percent:.1f}%")
            stats_table.add_row("Avg Signal", f"{m.avg_signal_strength_dbm:.1f} dBm")
            stats_table.add_row("Avg Throughput", f"{m.avg_throughput_mbps:.1f} Mbps")
            stats_table.add_row("Avg Latency", f"{m.avg_latency_ms:.1f} ms")
            stats_table.add_row("Mesh Links", str(len(m.link_from_drone)))
            stats_table.add_row("Backhaul", "✓ Active" if m.backhaul_active else "✗ Down")
            
            self.console.print(Panel(stats_table, title="Network Statistics"))
        
        # Drone table
        if self.latest_swarm:
            drone_table = Table(title="Drone Network Status")
            drone_table.add_column("ID", style="cyan")
            drone_table.add_column("Role", style="magenta")
            drone_table.add_column("Position", style="green")
            drone_table.add_column("Signal", style="yellow")
            drone_table.add_column("Neighbors", style="blue")
            
            for drone in self.latest_swarm.drones:
                role = "HUB" if drone.role == DroneState.ROLE_HUB else "LEAF"
                pos = f"({drone.position.x:.1f}, {drone.position.y:.1f}, {drone.position.z:.1f})"
                signal = f"{drone.signal_strength_dbm:.1f} dBm"
                neighbors = str(drone.connected_neighbors)
                
                # Color code signal strength
                if drone.signal_strength_dbm > -70:
                    signal = f"[green]{signal}[/green]"
                elif drone.signal_strength_dbm > -80:
                    signal = f"[yellow]{signal}[/yellow]"
                else:
                    signal = f"[red]{signal}[/red]"
                
                drone_table.add_row(
                    str(drone.drone_id),
                    role,
                    pos,
                    signal,
                    neighbors
                )
            
            self.console.print(drone_table)
        
        # ASCII coverage map (simplified)
        if self.latest_metrics and self.latest_metrics.coverage_mask:
            self._render_coverage_map()
    
    def _render_coverage_map(self):
        """Render a small ASCII coverage map"""
        m = self.latest_metrics
        
        # Downsample to 40x20 for terminal
        target_width = 40
        target_height = 15
        
        if m.grid_size_x == 0 or m.grid_size_y == 0:
            return
        
        # Reshape coverage mask
        coverage = np.array(m.coverage_mask).reshape(m.grid_size_y, m.grid_size_x)
        
        # Downsample
        step_x = max(1, m.grid_size_x // target_width)
        step_y = max(1, m.grid_size_y // target_height)
        
        downsampled = coverage[::step_y, ::step_x]
        
        # Render
        lines = []
        for row in downsampled:
            line = ""
            for cell in row:
                if cell:
                    line += "[green]█[/green]"
                else:
                    line += "[dim]·[/dim]"
            lines.append(line)
        
        map_text = "\n".join(lines)
        self.console.print(Panel(map_text, title="Coverage Map"))
    
    def simple_render(self):
        """Simple text output when rich is not available"""
        if self.latest_metrics:
            m = self.latest_metrics
            self.get_logger().info(
                f'Coverage: {m.total_coverage_percent:.1f}% | '
                f'Signal: {m.avg_signal_strength_dbm:.1f} dBm | '
                f'Throughput: {m.avg_throughput_mbps:.1f} Mbps | '
                f'Links: {len(m.link_from_drone)}'
            )


def main(args=None):
    rclpy.init(args=args)
    node = NetworkVisualizerNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
