"""
Launch file for A.U.R.A. network simulation.
"""

from launch import LaunchDescription
from launch_ros.actions import Node
import os
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    pkg_dir = get_package_share_directory('aura_network_sim')
    config_file = os.path.join(pkg_dir, 'config', 'network_sim_params.yaml')
    
    network_sim_node = Node(
        package='aura_network_sim',
        executable='network_sim_node',
        name='network_sim',
        parameters=[config_file],
        output='screen'
    )
    
    coverage_calc_node = Node(
        package='aura_network_sim',
        executable='coverage_calculator',
        name='coverage_calculator',
        parameters=[config_file],
        output='screen'
    )
    
    visualizer_node = Node(
        package='aura_network_sim',
        executable='network_visualizer',
        name='network_visualizer',
        parameters=[config_file],
        output='screen'
    )
    
    return LaunchDescription([
        network_sim_node,
        coverage_calc_node,
        # visualizer_node,  # Uncomment for TUI visualization
    ])
