#pragma once

#include "aura_trajectory/minco_trajectory.hpp"
#include <functional>
#include <optional>

namespace aura {

/**
 * @brief Configuration for trajectory optimization
 */
struct OptimizationConfig {
    // Penalty weights (lambda values from paper Eq. 8)
    double weight_smoothness = 1.0;      // J_s: minimize jerk integral
    double weight_time = 10.0;           // J_t: minimize total time
    double weight_obstacle = 1000.0;     // J_o: avoid obstacles (hard constraint)
    double weight_swarm = 1000.0;        // J_w: avoid other drones (hard constraint)
    double weight_dynamics = 1000.0;     // J_d: stay within physical limits
    double weight_formation = 1.0;       // J_f: maintain formation (soft)
    
    // Physical limits
    double max_velocity = 3.0;           // m/s
    double max_acceleration = 5.0;       // m/s^2
    double max_jerk = 20.0;              // m/s^3
    
    // Safety clearances
    double obstacle_clearance = 0.5;     // meters from obstacles
    double swarm_clearance = 0.8;        // meters from other drones
    
    // Solver settings
    int max_iterations = 100;
    double convergence_tolerance = 1e-4;
    int num_constraint_samples = 16;     // Samples per piece for constraint checking
    
    // Replanning
    double replan_horizon = 3.0;         // seconds ahead to plan
    int num_pieces = 8;                  // M: number of polynomial pieces
};

/**
 * @brief Obstacle representation (plane in 3D)
 */
struct Obstacle {
    Eigen::Vector3d point;    // Point on the plane
    Eigen::Vector3d normal;   // Normal vector pointing to free space
    
    // Distance from point p to obstacle (positive = free space)
    double distance(const Eigen::Vector3d& p) const {
        return (p - point).dot(normal);
    }
};

/**
 * @brief Result of trajectory optimization
 */
struct OptimizationResult {
    MincoTrajectory trajectory;
    bool feasible;
    double total_cost;
    int iterations;
    std::string message;
    
    // Individual costs for debugging
    double cost_smoothness;
    double cost_time;
    double cost_obstacle;
    double cost_swarm;
    double cost_dynamics;
};

/**
 * @brief Multi-objective trajectory optimizer using L-BFGS
 * 
 * Implements the optimization from Eq. 8: min sum(lambda_x * J_x)
 * Uses constraint transcription (soft penalties) for real-time performance.
 */
class TrajectoryOptimizer {
public:
    explicit TrajectoryOptimizer(const OptimizationConfig& config = OptimizationConfig());
    
    /**
     * @brief Optimize trajectory from current state to goal
     * 
     * @param start_pos Current position
     * @param start_vel Current velocity  
     * @param goal_pos Goal position
     * @param obstacles List of obstacles to avoid
     * @param other_trajectories Trajectories of other drones for collision avoidance
     * @return OptimizationResult containing the optimized trajectory
     */
    OptimizationResult optimize(
        const Eigen::Vector3d& start_pos,
        const Eigen::Vector3d& start_vel,
        const Eigen::Vector3d& goal_pos,
        const std::vector<Obstacle>& obstacles,
        const std::vector<MincoTrajectory>& other_trajectories
    );
    
    /**
     * @brief Re-optimize from a previous trajectory (warm start)
     */
    OptimizationResult reoptimize(
        const MincoTrajectory& initial_guess,
        const std::vector<Obstacle>& obstacles,
        const std::vector<MincoTrajectory>& other_trajectories
    );
    
    // Configuration
    void setConfig(const OptimizationConfig& config) { config_ = config; }
    const OptimizationConfig& getConfig() const { return config_; }
    
    // Set formation target (optional)
    void setFormationTarget(const Eigen::Vector3d& target) { 
        formation_target_ = target; 
    }
    
private:
    OptimizationConfig config_;
    std::optional<Eigen::Vector3d> formation_target_;
    
    // Current optimization state
    std::vector<Obstacle> current_obstacles_;
    std::vector<MincoTrajectory> current_other_trajectories_;
    double trajectory_start_time_;
    
    // Cost and gradient computation
    double computeTotalCost(const MincoTrajectory& traj);
    void computeGradients(const MincoTrajectory& traj,
                          Eigen::MatrixXd& grad_q,
                          Eigen::VectorXd& grad_T);
    
    // Individual penalty functions
    double computeSmoothnessPenalty(const MincoTrajectory& traj);
    double computeTimePenalty(const MincoTrajectory& traj);
    double computeObstaclePenalty(const MincoTrajectory& traj);
    double computeSwarmPenalty(const MincoTrajectory& traj);
    double computeDynamicsPenalty(const MincoTrajectory& traj);
    double computeFormationPenalty(const MincoTrajectory& traj);
    
    // L-BFGS interface
    static double lbfgsCallback(void* instance, const double* x, double* g, 
                                int n, double step);
    
    // Convert between MINCO parameters and flat optimization vector
    void paramsToVector(const MincoTrajectory::Waypoints& q, 
                        const MincoTrajectory::TimeAlloc& T,
                        Eigen::VectorXd& x);
    void vectorToParams(const Eigen::VectorXd& x,
                        MincoTrajectory::Waypoints& q,
                        MincoTrajectory::TimeAlloc& T);
};

}  // namespace aura
