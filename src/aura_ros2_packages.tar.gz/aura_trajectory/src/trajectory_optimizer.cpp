#include "aura_trajectory/trajectory_optimizer.hpp"
#include "aura_trajectory/penalty_functions.hpp"
#include <lbfgs.h>
#include <iostream>

namespace aura {

TrajectoryOptimizer::TrajectoryOptimizer(const OptimizationConfig& config)
    : config_(config) {}

OptimizationResult TrajectoryOptimizer::optimize(
    const Eigen::Vector3d& start_pos,
    const Eigen::Vector3d& start_vel,
    const Eigen::Vector3d& goal_pos,
    const std::vector<Obstacle>& obstacles,
    const std::vector<MincoTrajectory>& other_trajectories)
{
    current_obstacles_ = obstacles;
    current_other_trajectories_ = other_trajectories;
    trajectory_start_time_ = 0.0;  // Assume starting now
    
    OptimizationResult result;
    
    // Initialize trajectory with straight line
    int M = config_.num_pieces;
    Eigen::Vector3d direction = goal_pos - start_pos;
    double distance = direction.norm();
    
    if (distance < 1e-6) {
        // Already at goal
        result.feasible = true;
        result.message = "Already at goal";
        result.trajectory = MincoTrajectory();
        return result;
    }
    
    // Estimate time based on max velocity
    double estimated_time = distance / config_.max_velocity * 1.5;  // Add buffer
    
    // Create uniform time allocation
    MincoTrajectory::TimeAlloc T = Eigen::VectorXd::Constant(M, estimated_time / M);
    
    // Create waypoints along straight line (will be optimized)
    MincoTrajectory::Waypoints q(3, M - 1);
    for (int i = 0; i < M - 1; ++i) {
        double alpha = static_cast<double>(i + 1) / M;
        q.col(i) = start_pos + alpha * direction;
    }
    
    // Create initial trajectory
    MincoTrajectory traj(q, T, start_pos, start_vel, goal_pos, Eigen::Vector3d::Zero());
    
    if (!traj.isValid()) {
        result.feasible = false;
        result.message = "Failed to create initial trajectory";
        return result;
    }
    
    // Pack parameters into optimization vector
    // x = [q_0x, q_0y, q_0z, q_1x, ..., T_0, T_1, ...]
    int num_waypoints = M - 1;
    int n = 3 * num_waypoints + M;  // Total optimization variables
    
    Eigen::VectorXd x(n);
    for (int i = 0; i < num_waypoints; ++i) {
        x.segment<3>(3 * i) = q.col(i);
    }
    x.tail(M) = T;
    
    // L-BFGS optimization
    lbfgs_parameter_t params;
    lbfgs_parameter_init(&params);
    params.max_iterations = config_.max_iterations;
    params.epsilon = config_.convergence_tolerance;
    
    double final_cost;
    
    // Store 'this' pointer and trajectory info for callback
    struct OptData {
        TrajectoryOptimizer* optimizer;
        Eigen::Vector3d start_pos, start_vel, goal_pos;
        int M;
    };
    OptData data{this, start_pos, start_vel, goal_pos, M};
    
    // Custom callback wrapper
    auto callback = [](void* instance, const lbfgsfloatval_t* x_ptr, 
                       lbfgsfloatval_t* g_ptr, int n_vars, lbfgsfloatval_t) -> lbfgsfloatval_t {
        OptData* data = static_cast<OptData*>(instance);
        TrajectoryOptimizer* opt = data->optimizer;
        
        int M = data->M;
        int num_waypoints = M - 1;
        
        // Unpack parameters
        MincoTrajectory::Waypoints q(3, num_waypoints);
        MincoTrajectory::TimeAlloc T(M);
        
        for (int i = 0; i < num_waypoints; ++i) {
            q.col(i) = Eigen::Vector3d(x_ptr[3*i], x_ptr[3*i+1], x_ptr[3*i+2]);
        }
        for (int i = 0; i < M; ++i) {
            T(i) = std::max(0.01, x_ptr[3*num_waypoints + i]);  // Ensure positive time
        }
        
        // Create trajectory
        MincoTrajectory traj(q, T, data->start_pos, data->start_vel, 
                            data->goal_pos, Eigen::Vector3d::Zero());
        
        if (!traj.isValid()) {
            // Return large cost for invalid trajectories
            return 1e10;
        }
        
        // Compute cost
        double cost = opt->computeTotalCost(traj);
        
        // Compute gradients (numerical for now)
        double eps = 1e-6;
        for (int i = 0; i < n_vars; ++i) {
            Eigen::VectorXd x_plus(n_vars);
            for (int j = 0; j < n_vars; ++j) {
                x_plus(j) = x_ptr[j];
            }
            x_plus(i) += eps;
            
            // Unpack perturbed
            MincoTrajectory::Waypoints q_plus(3, num_waypoints);
            MincoTrajectory::TimeAlloc T_plus(M);
            for (int j = 0; j < num_waypoints; ++j) {
                q_plus.col(j) = Eigen::Vector3d(x_plus[3*j], x_plus[3*j+1], x_plus[3*j+2]);
            }
            for (int j = 0; j < M; ++j) {
                T_plus(j) = std::max(0.01, x_plus(3*num_waypoints + j));
            }
            
            MincoTrajectory traj_plus(q_plus, T_plus, data->start_pos, data->start_vel,
                                      data->goal_pos, Eigen::Vector3d::Zero());
            
            double cost_plus = traj_plus.isValid() ? opt->computeTotalCost(traj_plus) : 1e10;
            g_ptr[i] = (cost_plus - cost) / eps;
        }
        
        return cost;
    };
    
    int ret = lbfgs(n, x.data(), &final_cost, callback, nullptr, &data, &params);
    
    // Unpack final result
    for (int i = 0; i < num_waypoints; ++i) {
        q.col(i) = x.segment<3>(3 * i);
    }
    T = x.tail(M);
    for (int i = 0; i < M; ++i) {
        T(i) = std::max(0.01, T(i));
    }
    
    result.trajectory = MincoTrajectory(q, T, start_pos, start_vel, goal_pos, Eigen::Vector3d::Zero());
    result.total_cost = final_cost;
    result.iterations = params.max_iterations;  // Approximate
    
    if (ret == LBFGS_SUCCESS || ret == LBFGS_ALREADY_MINIMIZED) {
        result.feasible = true;
        result.message = "Optimization converged";
    } else {
        result.feasible = result.trajectory.isValid();
        result.message = "Optimization terminated with code " + std::to_string(ret);
    }
    
    // Compute individual costs for debugging
    if (result.trajectory.isValid()) {
        result.cost_smoothness = penalties::smoothness_penalty(result.trajectory);
        result.cost_time = penalties::time_penalty(result.trajectory);
        result.cost_obstacle = computeObstaclePenalty(result.trajectory);
        result.cost_swarm = computeSwarmPenalty(result.trajectory);
        result.cost_dynamics = computeDynamicsPenalty(result.trajectory);
    }
    
    return result;
}

OptimizationResult TrajectoryOptimizer::reoptimize(
    const MincoTrajectory& initial_guess,
    const std::vector<Obstacle>& obstacles,
    const std::vector<MincoTrajectory>& other_trajectories)
{
    if (!initial_guess.isValid()) {
        OptimizationResult result;
        result.feasible = false;
        result.message = "Invalid initial guess";
        return result;
    }
    
    // Extract boundary conditions from initial guess
    Eigen::Vector3d start_pos = initial_guess.getPosition(0);
    Eigen::Vector3d start_vel = initial_guess.getVelocity(0);
    double total_time = initial_guess.getTotalDuration();
    Eigen::Vector3d goal_pos = initial_guess.getPosition(total_time);
    
    return optimize(start_pos, start_vel, goal_pos, obstacles, other_trajectories);
}

double TrajectoryOptimizer::computeTotalCost(const MincoTrajectory& traj) {
    double cost = 0.0;
    
    cost += config_.weight_smoothness * computeSmoothnessPenalty(traj);
    cost += config_.weight_time * computeTimePenalty(traj);
    cost += config_.weight_obstacle * computeObstaclePenalty(traj);
    cost += config_.weight_swarm * computeSwarmPenalty(traj);
    cost += config_.weight_dynamics * computeDynamicsPenalty(traj);
    
    if (formation_target_.has_value()) {
        cost += config_.weight_formation * computeFormationPenalty(traj);
    }
    
    return cost;
}

double TrajectoryOptimizer::computeSmoothnessPenalty(const MincoTrajectory& traj) {
    return penalties::smoothness_penalty(traj);
}

double TrajectoryOptimizer::computeTimePenalty(const MincoTrajectory& traj) {
    return penalties::time_penalty(traj);
}

double TrajectoryOptimizer::computeObstaclePenalty(const MincoTrajectory& traj) {
    double total = 0.0;
    for (const auto& obs : current_obstacles_) {
        total += penalties::obstacle_penalty(traj, obs.point, obs.normal,
                                             config_.obstacle_clearance,
                                             config_.num_constraint_samples);
    }
    return total;
}

double TrajectoryOptimizer::computeSwarmPenalty(const MincoTrajectory& traj) {
    double total = 0.0;
    for (const auto& other : current_other_trajectories_) {
        total += penalties::swarm_penalty(traj, other, trajectory_start_time_,
                                          config_.swarm_clearance,
                                          config_.num_constraint_samples);
    }
    return total;
}

double TrajectoryOptimizer::computeDynamicsPenalty(const MincoTrajectory& traj) {
    double cost = 0.0;
    cost += penalties::velocity_penalty(traj, config_.max_velocity, 
                                        config_.num_constraint_samples);
    cost += penalties::acceleration_penalty(traj, config_.max_acceleration,
                                            config_.num_constraint_samples);
    cost += penalties::jerk_penalty(traj, config_.max_jerk,
                                    config_.num_constraint_samples);
    return cost;
}

double TrajectoryOptimizer::computeFormationPenalty(const MincoTrajectory& traj) {
    if (!formation_target_.has_value()) return 0.0;
    return penalties::formation_penalty(traj, formation_target_.value());
}

}  // namespace aura
