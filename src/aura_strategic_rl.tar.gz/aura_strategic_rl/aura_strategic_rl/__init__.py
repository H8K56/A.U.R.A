"""
A.U.R.A. Strategic RL Package

Provides reinforcement learning-based swarm positioning for disaster relief:
- Gymnasium environment for swarm simulation
- PPO policy network for coverage optimization
- Baseline controllers (grid formation, HHO)
- ROS 2 integration for real-time deployment

The RL policy activates AFTER network establishment (not during takeoff).
"""

__version__ = '0.1.0'
