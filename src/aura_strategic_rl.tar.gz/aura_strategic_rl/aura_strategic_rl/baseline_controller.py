"""
Baseline Controllers for A.U.R.A.

Non-learned controllers for comparison and fallback:
- GridFormationController: Fixed grid pattern
- HarrisHawksOptimizer: Metaheuristic optimization
- CentroidSpreadController: Simple heuristic
"""

import numpy as np
from typing import List, Tuple, Optional, Dict
from dataclasses import dataclass


@dataclass
class ControllerConfig:
    """Configuration for baseline controllers"""
    num_drones: int = 5
    area_size: float = 200.0
    min_altitude: float = 20.0
    max_altitude: float = 60.0
    target_altitude: float = 35.0
    min_separation: float = 20.0
    update_rate: float = 0.5  # Hz


class GridFormationController:
    """
    Simple grid formation controller.
    
    Arranges drones in a regular grid pattern to maximize coverage.
    Good baseline but doesn't adapt to terrain or demand.
    """
    
    def __init__(self, config: ControllerConfig = None):
        self.config = config or ControllerConfig()
        self.grid_positions: List[np.ndarray] = []
        self._compute_grid()
    
    def _compute_grid(self):
        """Compute optimal grid positions"""
        n = self.config.num_drones
        
        # Compute grid dimensions
        # For coverage, roughly sqrt(n) x sqrt(n) grid
        cols = int(np.ceil(np.sqrt(n)))
        rows = int(np.ceil(n / cols))
        
        # Compute spacing
        spacing = self.config.area_size * 0.8 / max(cols, rows)
        
        # Center the grid
        x_offset = -(cols - 1) * spacing / 2
        y_offset = -(rows - 1) * spacing / 2
        
        self.grid_positions = []
        for i in range(n):
            row = i // cols
            col = i % cols
            
            pos = np.array([
                x_offset + col * spacing,
                y_offset + row * spacing,
                self.config.target_altitude
            ])
            self.grid_positions.append(pos)
    
    def get_goal_positions(self, 
                           current_positions: List[np.ndarray]
                           ) -> List[np.ndarray]:
        """Get goal positions for all drones"""
        return self.grid_positions.copy()
    
    def get_actions(self, 
                    current_positions: List[np.ndarray],
                    max_delta: float = 10.0
                    ) -> np.ndarray:
        """Get action deltas to move toward grid positions"""
        goals = self.get_goal_positions(current_positions)
        
        actions = []
        for current, goal in zip(current_positions, goals):
            delta = goal - current
            dist = np.linalg.norm(delta)
            
            if dist > max_delta:
                delta = delta / dist * max_delta
            
            # Normalize to [-1, 1]
            normalized = delta / max_delta
            actions.append(normalized)
        
        return np.concatenate(actions).astype(np.float32)


class HarrisHawksOptimizer:
    """
    Harris Hawks Optimizer for swarm positioning.
    
    Bio-inspired metaheuristic that simulates cooperative hunting behavior.
    Used as a strong baseline and for initialization.
    
    Reference: Heidari et al., "Harris hawks optimization: Algorithm and applications"
    """
    
    def __init__(self, config: ControllerConfig = None):
        self.config = config or ControllerConfig()
        
        # HHO parameters
        self.population_size = 20
        self.max_iterations = 50
        self.E0 = 2.0  # Initial energy
        
        # State
        self.best_position: Optional[np.ndarray] = None
        self.best_fitness: float = -np.inf
        self.iteration = 0
    
    def optimize(self,
                 current_positions: List[np.ndarray],
                 coverage_func,
                 connectivity_func,
                 max_iterations: int = None
                 ) -> List[np.ndarray]:
        """
        Run HHO optimization.
        
        Args:
            current_positions: Current drone positions
            coverage_func: Function to evaluate coverage (positions -> float)
            connectivity_func: Function to check connectivity (positions -> bool)
            max_iterations: Override default max iterations
            
        Returns:
            Optimized positions for all drones
        """
        n_drones = len(current_positions)
        dim = n_drones * 3  # x, y, z for each drone
        
        max_iter = max_iterations or self.max_iterations
        
        # Initialize population
        population = self._init_population(current_positions, self.population_size)
        fitness = np.array([self._evaluate(p, coverage_func, connectivity_func) 
                           for p in population])
        
        # Best solution (rabbit)
        best_idx = np.argmax(fitness)
        rabbit_pos = population[best_idx].copy()
        rabbit_fitness = fitness[best_idx]
        
        # Main optimization loop
        for t in range(max_iter):
            E1 = 2 * (1 - t / max_iter)  # Decreasing energy
            
            for i in range(self.population_size):
                E0 = 2 * np.random.random() - 1
                E = E1 * E0  # Escaping energy
                
                if abs(E) >= 1:
                    # Exploration phase
                    population[i] = self._exploration(population, i, rabbit_pos)
                else:
                    # Exploitation phase
                    r = np.random.random()
                    
                    if r >= 0.5:
                        # Soft besiege
                        if abs(E) >= 0.5:
                            population[i] = self._soft_besiege(
                                population[i], rabbit_pos, E
                            )
                        else:
                            # Hard besiege
                            population[i] = self._hard_besiege(
                                population[i], rabbit_pos, E
                            )
                    else:
                        # Rapid dives (Levy flight)
                        if abs(E) >= 0.5:
                            population[i] = self._soft_besiege_levy(
                                population[i], rabbit_pos, E, dim
                            )
                        else:
                            population[i] = self._hard_besiege_levy(
                                population[i], rabbit_pos, E, dim
                            )
                
                # Apply constraints
                population[i] = self._apply_constraints(population[i], n_drones)
                
                # Evaluate
                fitness[i] = self._evaluate(population[i], coverage_func, connectivity_func)
                
                # Update rabbit
                if fitness[i] > rabbit_fitness:
                    rabbit_pos = population[i].copy()
                    rabbit_fitness = fitness[i]
        
        self.best_position = rabbit_pos
        self.best_fitness = rabbit_fitness
        
        # Convert to list of positions
        return self._flat_to_positions(rabbit_pos, n_drones)
    
    def _init_population(self, 
                         current_positions: List[np.ndarray],
                         pop_size: int) -> List[np.ndarray]:
        """Initialize population around current positions"""
        current_flat = np.concatenate(current_positions)
        dim = len(current_flat)
        
        population = []
        
        # First individual is current position
        population.append(current_flat.copy())
        
        # Rest are random perturbations
        for _ in range(pop_size - 1):
            noise = np.random.normal(0, 20, dim)
            individual = current_flat + noise
            population.append(individual)
        
        return population
    
    def _evaluate(self, 
                  flat_positions: np.ndarray,
                  coverage_func,
                  connectivity_func) -> float:
        """Evaluate fitness of a solution"""
        n_drones = len(flat_positions) // 3
        positions = self._flat_to_positions(flat_positions, n_drones)
        
        # Coverage score (primary objective)
        coverage = coverage_func(positions)
        
        # Connectivity (constraint)
        connected = connectivity_func(positions)
        
        # Separation penalty
        separation_penalty = 0.0
        for i in range(n_drones):
            for j in range(i + 1, n_drones):
                dist = np.linalg.norm(positions[i] - positions[j])
                if dist < self.config.min_separation:
                    separation_penalty += (self.config.min_separation - dist) ** 2
        
        # Combined fitness
        fitness = coverage
        
        if not connected:
            fitness -= 50.0  # Heavy penalty for disconnection
        
        fitness -= separation_penalty * 0.1
        
        return fitness
    
    def _flat_to_positions(self, 
                           flat: np.ndarray, 
                           n_drones: int) -> List[np.ndarray]:
        """Convert flat array to list of positions"""
        return [flat[i*3:(i+1)*3].copy() for i in range(n_drones)]
    
    def _exploration(self, population, i, rabbit_pos):
        """Exploration phase - random walk"""
        rand_idx = np.random.randint(len(population))
        X_rand = population[rand_idx]
        
        q = np.random.random()
        if q >= 0.5:
            return X_rand - np.random.random() * np.abs(X_rand - 2 * np.random.random() * population[i])
        else:
            return (rabbit_pos - np.mean(population, axis=0)) - np.random.random() * (
                np.random.random() * (self.config.area_size - (-self.config.area_size)) + (-self.config.area_size)
            )
    
    def _soft_besiege(self, X, rabbit_pos, E):
        """Soft besiege phase"""
        J = 2 * (1 - np.random.random())
        delta = rabbit_pos - X
        return rabbit_pos - E * np.abs(J * rabbit_pos - X)
    
    def _hard_besiege(self, X, rabbit_pos, E):
        """Hard besiege phase"""
        return rabbit_pos - E * np.abs(rabbit_pos - X)
    
    def _levy_flight(self, dim):
        """Generate Levy flight step"""
        import math
        beta = 1.5
        sigma = (math.gamma(1 + beta) * np.sin(np.pi * beta / 2) / 
                (math.gamma((1 + beta) / 2) * beta * 2**((beta - 1) / 2))) ** (1 / beta)
        
        u = np.random.normal(0, sigma, dim)
        v = np.random.normal(0, 1, dim)
        
        return u / (np.abs(v) ** (1 / beta))
    
    def _soft_besiege_levy(self, X, rabbit_pos, E, dim):
        """Soft besiege with Levy flight"""
        J = 2 * (1 - np.random.random())
        Y = rabbit_pos - E * np.abs(J * rabbit_pos - X)
        Z = Y + np.random.random(dim) * self._levy_flight(dim)
        return Z
    
    def _hard_besiege_levy(self, X, rabbit_pos, E, dim):
        """Hard besiege with Levy flight"""
        J = 2 * (1 - np.random.random())
        Y = rabbit_pos - E * np.abs(J * rabbit_pos - np.mean([X, rabbit_pos], axis=0))
        Z = Y + np.random.random(dim) * self._levy_flight(dim)
        return Z
    
    def _apply_constraints(self, X, n_drones):
        """Apply position constraints"""
        for i in range(n_drones):
            # XY bounds
            X[i*3] = np.clip(X[i*3], -self.config.area_size, self.config.area_size)
            X[i*3 + 1] = np.clip(X[i*3 + 1], -self.config.area_size, self.config.area_size)
            # Z bounds
            X[i*3 + 2] = np.clip(X[i*3 + 2], self.config.min_altitude, self.config.max_altitude)
        
        return X


class CentroidSpreadController:
    """
    Simple heuristic controller that spreads drones from centroid.
    
    Fast and simple baseline for comparison.
    """
    
    def __init__(self, config: ControllerConfig = None):
        self.config = config or ControllerConfig()
        self.target_radius = 60.0
    
    def get_actions(self,
                    current_positions: List[np.ndarray],
                    coverage_grid: np.ndarray = None
                    ) -> np.ndarray:
        """
        Get actions to spread drones from centroid.
        
        Args:
            current_positions: Current drone positions
            coverage_grid: Optional coverage map for smarter movement
            
        Returns:
            Normalized action array
        """
        n = len(current_positions)
        centroid = np.mean(current_positions, axis=0)
        
        actions = []
        
        for i, pos in enumerate(current_positions):
            direction = pos - centroid
            dist = np.linalg.norm(direction[:2])
            
            if dist < 1.0:
                # Assign radial direction based on index
                angle = 2 * np.pi * i / n
                direction = np.array([np.cos(angle), np.sin(angle), 0])
            else:
                direction = direction / dist
                direction[2] = 0  # Keep altitude component zero
            
            # Move toward target radius
            if dist < self.target_radius:
                action = direction * 0.5
            elif dist > self.target_radius * 1.5:
                action = -direction * 0.3
            else:
                action = direction * 0.1
            
            # Altitude correction
            z_error = self.config.target_altitude - pos[2]
            action[2] = np.clip(z_error / 10.0, -0.5, 0.5)
            
            actions.append(np.clip(action, -1, 1))
        
        return np.concatenate(actions).astype(np.float32)
