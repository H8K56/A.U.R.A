"""
Observation and Action Space Definitions for A.U.R.A. RL

Defines the observation and action spaces used by the RL policy.
Observation space is ~140-dimensional covering:
- Drone positions and states
- Network metrics
- Coverage information
- Environmental conditions

Action space provides position offsets for each drone.
"""

import numpy as np
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional


@dataclass
class ObservationConfig:
    """Configuration for observation space"""
    
    # Swarm
    num_drones: int = 5
    
    # Per-drone observation dimensions
    drone_position_dim: int = 3      # x, y, z (normalized)
    drone_velocity_dim: int = 3      # vx, vy, vz
    drone_state_dim: int = 3         # battery, signal, neighbors
    
    # Network observation
    coverage_grid_size: int = 10     # 10x10 downsampled coverage
    network_metrics_dim: int = 4     # coverage%, avg_signal, throughput, latency
    
    # Per-drone network state
    drone_network_dim: int = 4       # rssi, throughput, latency, hops_to_hub
    
    # Environment
    num_weather_zones: int = 3       # Max weather zones to track
    weather_zone_dim: int = 5        # x, y, radius, attenuation, active
    
    @property
    def drone_obs_dim(self) -> int:
        """Total observation per drone"""
        return (self.drone_position_dim + 
                self.drone_velocity_dim + 
                self.drone_state_dim +
                self.drone_network_dim)
    
    @property
    def total_obs_dim(self) -> int:
        """Total observation dimension"""
        swarm_dim = self.num_drones * self.drone_obs_dim
        coverage_dim = self.coverage_grid_size ** 2
        network_dim = self.network_metrics_dim
        weather_dim = self.num_weather_zones * self.weather_zone_dim
        
        return swarm_dim + coverage_dim + network_dim + weather_dim


@dataclass
class ActionConfig:
    """Configuration for action space"""
    
    num_drones: int = 5
    
    # Per-drone action dimensions
    position_delta_dim: int = 3      # dx, dy, dz
    
    # Action scaling
    max_delta_xy: float = 10.0       # Max horizontal movement per step (m)
    max_delta_z: float = 5.0         # Max vertical movement per step (m)
    
    # Position bounds
    min_altitude: float = 15.0       # Minimum flight altitude (m)
    max_altitude: float = 80.0       # Maximum flight altitude (m)
    area_bound: float = 200.0        # Max distance from origin (m)
    
    @property
    def action_dim(self) -> int:
        """Total action dimension"""
        return self.num_drones * self.position_delta_dim


class ObservationBuilder:
    """
    Builds observation vectors from ROS messages.
    
    Normalizes all values to roughly [-1, 1] or [0, 1] range
    for stable neural network training.
    """
    
    def __init__(self, config: ObservationConfig):
        self.config = config
        
        # Normalization constants
        self.position_scale = 200.0   # meters
        self.velocity_scale = 5.0     # m/s
        self.altitude_scale = 100.0   # meters
        self.rssi_offset = 100.0      # dBm (shift to positive)
        self.rssi_scale = 50.0        # dBm range
    
    def build_from_messages(self, 
                            swarm_state,  # SwarmState msg
                            network_metrics,  # NetworkMetrics msg
                            weather_zones: List = None) -> np.ndarray:
        """Build observation from ROS messages"""
        obs_parts = []
        
        # 1. Per-drone observations
        drone_obs = self._build_drone_obs(swarm_state, network_metrics)
        obs_parts.append(drone_obs)
        
        # 2. Coverage grid (downsampled)
        coverage_obs = self._build_coverage_obs(network_metrics)
        obs_parts.append(coverage_obs)
        
        # 3. Global network metrics
        network_obs = self._build_network_obs(network_metrics)
        obs_parts.append(network_obs)
        
        # 4. Weather zones
        weather_obs = self._build_weather_obs(weather_zones or [])
        obs_parts.append(weather_obs)
        
        return np.concatenate(obs_parts).astype(np.float32)
    
    def _build_drone_obs(self, swarm_state, network_metrics) -> np.ndarray:
        """Build per-drone observation"""
        obs = np.zeros((self.config.num_drones, self.config.drone_obs_dim))
        
        if swarm_state is None:
            return obs.flatten()
        
        for i, drone in enumerate(swarm_state.drones[:self.config.num_drones]):
            idx = 0
            
            # Position (normalized)
            obs[i, idx:idx+3] = [
                drone.position.x / self.position_scale,
                drone.position.y / self.position_scale,
                drone.position.z / self.altitude_scale,
            ]
            idx += 3
            
            # Velocity (normalized)
            obs[i, idx:idx+3] = [
                drone.velocity.x / self.velocity_scale,
                drone.velocity.y / self.velocity_scale,
                drone.velocity.z / self.velocity_scale,
            ]
            idx += 3
            
            # State
            obs[i, idx:idx+3] = [
                drone.battery_percent / 100.0,
                (drone.signal_strength_dbm + self.rssi_offset) / self.rssi_scale,
                drone.connected_neighbors / self.config.num_drones,
            ]
            idx += 3
            
            # Network (from metrics if available)
            obs[i, idx:idx+4] = [
                drone.throughput_mbps / 100.0,
                drone.latency_ms / 100.0,
                0.0,  # hops_to_hub (would need to track)
                1.0 if drone.role == 1 else 0.0,  # is_hub
            ]
        
        return obs.flatten()
    
    def _build_coverage_obs(self, network_metrics) -> np.ndarray:
        """Build downsampled coverage grid observation"""
        grid_size = self.config.coverage_grid_size
        obs = np.zeros(grid_size * grid_size)
        
        if network_metrics is None or not network_metrics.coverage_mask:
            return obs
        
        try:
            # Reshape original coverage
            orig_h = network_metrics.grid_size_y
            orig_w = network_metrics.grid_size_x
            coverage = np.array(network_metrics.coverage_mask).reshape(orig_h, orig_w)
            
            # Downsample by averaging
            step_h = max(1, orig_h // grid_size)
            step_w = max(1, orig_w // grid_size)
            
            for i in range(grid_size):
                for j in range(grid_size):
                    h_start = i * step_h
                    h_end = min((i + 1) * step_h, orig_h)
                    w_start = j * step_w
                    w_end = min((j + 1) * step_w, orig_w)
                    
                    obs[i * grid_size + j] = np.mean(
                        coverage[h_start:h_end, w_start:w_end]
                    )
        except (ValueError, AttributeError):
            pass
        
        return obs
    
    def _build_network_obs(self, network_metrics) -> np.ndarray:
        """Build global network metrics observation"""
        obs = np.zeros(self.config.network_metrics_dim)
        
        if network_metrics is None:
            return obs
        
        obs[0] = network_metrics.total_coverage_percent / 100.0
        obs[1] = (network_metrics.avg_signal_strength_dbm + self.rssi_offset) / self.rssi_scale
        obs[2] = network_metrics.avg_throughput_mbps / 100.0
        obs[3] = network_metrics.avg_latency_ms / 100.0
        
        return obs
    
    def _build_weather_obs(self, weather_zones: List) -> np.ndarray:
        """Build weather zone observations"""
        obs = np.zeros(self.config.num_weather_zones * self.config.weather_zone_dim)
        
        for i, zone in enumerate(weather_zones[:self.config.num_weather_zones]):
            idx = i * self.config.weather_zone_dim
            obs[idx:idx+5] = [
                zone.center.x / self.position_scale,
                zone.center.y / self.position_scale,
                zone.radius_meters / self.position_scale,
                zone.signal_attenuation_db / 20.0,  # Normalize
                1.0 if zone.is_active else 0.0,
            ]
        
        return obs


class ActionProcessor:
    """
    Processes raw action outputs from policy network.
    
    Converts normalized actions [-1, 1] to position deltas,
    applies constraints, and generates CoverageGoal messages.
    """
    
    def __init__(self, config: ActionConfig):
        self.config = config
    
    def process_actions(self, 
                        raw_actions: np.ndarray,
                        current_positions: List[Tuple[float, float, float]]
                        ) -> List[Tuple[float, float, float]]:
        """
        Process raw policy actions into goal positions.
        
        Args:
            raw_actions: Policy output, shape (num_drones * 3,), values in [-1, 1]
            current_positions: List of current (x, y, z) positions
            
        Returns:
            List of goal (x, y, z) positions
        """
        actions = raw_actions.reshape(self.config.num_drones, 3)
        goal_positions = []
        
        for i, (action, current) in enumerate(zip(actions, current_positions)):
            # Scale actions to position deltas
            dx = action[0] * self.config.max_delta_xy
            dy = action[1] * self.config.max_delta_xy
            dz = action[2] * self.config.max_delta_z
            
            # Compute new position
            new_x = current[0] + dx
            new_y = current[1] + dy
            new_z = current[2] + dz
            
            # Apply position bounds
            new_x = np.clip(new_x, -self.config.area_bound, self.config.area_bound)
            new_y = np.clip(new_y, -self.config.area_bound, self.config.area_bound)
            new_z = np.clip(new_z, self.config.min_altitude, self.config.max_altitude)
            
            goal_positions.append((float(new_x), float(new_y), float(new_z)))
        
        return goal_positions
    
    def compute_action_penalty(self, raw_actions: np.ndarray) -> float:
        """Compute penalty for large actions (energy cost proxy)"""
        actions = raw_actions.reshape(-1, 3)
        
        # L2 norm of position deltas
        delta_magnitude = np.linalg.norm(actions[:, :2], axis=1)  # XY only
        
        # Penalize large movements
        penalty = np.mean(delta_magnitude) * 0.01
        
        return penalty
