#!/usr/bin/env python3
"""
Strategic RL Node for A.U.R.A.

ROS 2 node that runs the trained RL policy or baseline controller.
Subscribes to swarm state and network metrics, publishes coverage goals.

The RL policy only activates AFTER the swarm is in OPERATIONS phase
(network established, drones in position). During other phases,
uses safe baseline controller.
"""

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy

import numpy as np
from typing import Optional, List, Tuple
from pathlib import Path
from enum import IntEnum

from geometry_msgs.msg import Point
from std_msgs.msg import Header

# Import policy and baseline
from .spaces import ObservationConfig, ActionConfig, ObservationBuilder, ActionProcessor
from .policy import MLPPolicy, PolicyCheckpoint, BaselinePolicy
from .baseline_controller import GridFormationController, CentroidSpreadController

try:
    from aura_msgs.msg import SwarmState, NetworkMetrics, CoverageGoal, MissionStatus
    MSGS_AVAILABLE = True
except ImportError:
    MSGS_AVAILABLE = False
    SwarmState = None
    NetworkMetrics = None
    CoverageGoal = None
    MissionStatus = None


class MissionPhase(IntEnum):
    """Mission phases (matches aura_mission_control)"""
    IDLE = 0
    PREFLIGHT = 1
    TAKEOFF = 2
    TRANSIT = 3
    FORMATION = 4
    OPERATIONS = 5  # RL active only in this phase
    RTL = 6
    LANDING = 7
    EMERGENCY = 8


class StrategicRLNode(Node):
    """
    Strategic RL policy node.
    
    Subscribes:
        /swarm/state (SwarmState): Current swarm state
        /network/metrics (NetworkMetrics): Network metrics
        /mission/status (MissionStatus): Current mission phase
        
    Publishes:
        /drone_N/coverage_goal (CoverageGoal): Goal for each drone
    """
    
    def __init__(self):
        super().__init__('strategic_rl')
        
        # Declare parameters
        self.declare_parameter('num_drones', 5)
        self.declare_parameter('update_rate_hz', 1.0)
        self.declare_parameter('policy_path', '')
        self.declare_parameter('use_baseline', True)
        self.declare_parameter('baseline_type', 'spread')  # 'spread', 'grid', 'hho'
        
        # Global params
        self.declare_parameter('area_x_min', -200.0)
        self.declare_parameter('area_x_max', 200.0)
        self.declare_parameter('min_altitude', 15.0)
        self.declare_parameter('max_altitude', 80.0)
        
        # Get parameters
        self.num_drones = self.get_parameter('num_drones').value
        update_rate = self.get_parameter('update_rate_hz').value
        policy_path = self.get_parameter('policy_path').value
        self.use_baseline = self.get_parameter('use_baseline').value
        baseline_type = self.get_parameter('baseline_type').value
        
        # Area bounds
        x_min = self.get_parameter('area_x_min').value
        x_max = self.get_parameter('area_x_max').value
        self.area_bound = max(abs(x_min), abs(x_max))
        self.min_altitude = self.get_parameter('min_altitude').value
        self.max_altitude = self.get_parameter('max_altitude').value
        
        # Initialize observation/action processing
        self.obs_config = ObservationConfig(num_drones=self.num_drones)
        self.action_config = ActionConfig(
            num_drones=self.num_drones,
            area_bound=self.area_bound,
            min_altitude=self.min_altitude,
            max_altitude=self.max_altitude,
        )
        self.obs_builder = ObservationBuilder(self.obs_config)
        self.action_processor = ActionProcessor(self.action_config)
        
        # Initialize policy
        self.policy = None
        self.baseline = None
        
        if policy_path and Path(policy_path).exists():
            try:
                self.policy, metadata = PolicyCheckpoint.load(policy_path)
                self.get_logger().info(f'Loaded policy from {policy_path}')
                self.use_baseline = False
            except Exception as e:
                self.get_logger().error(f'Failed to load policy: {e}')
                self.use_baseline = True
        
        if self.use_baseline:
            if baseline_type == 'grid':
                self.baseline = GridFormationController()
            else:
                self.baseline = CentroidSpreadController()
            self.get_logger().info(f'Using baseline controller: {baseline_type}')
        
        # State
        self.latest_swarm: Optional[SwarmState] = None
        self.latest_metrics: Optional[NetworkMetrics] = None
        self.current_phase = MissionPhase.IDLE
        self.rl_active = False
        
        # QoS
        qos = QoSProfile(reliability=ReliabilityPolicy.RELIABLE, depth=10)
        
        # Subscribers
        if MSGS_AVAILABLE:
            self.swarm_sub = self.create_subscription(
                SwarmState, '/swarm/state',
                self.swarm_callback, qos
            )
            
            self.metrics_sub = self.create_subscription(
                NetworkMetrics, '/network/metrics',
                self.metrics_callback, qos
            )
            
            self.mission_sub = self.create_subscription(
                MissionStatus, '/mission/status',
                self.mission_callback, qos
            )
            
            # Publishers (one per drone)
            self.goal_pubs = {}
            for i in range(self.num_drones):
                topic = f'/drone_{i}/coverage_goal'
                self.goal_pubs[i] = self.create_publisher(CoverageGoal, topic, qos)
        else:
            self.get_logger().warn('aura_msgs not available, running in test mode')
        
        # Timer
        self.control_timer = self.create_timer(1.0 / update_rate, self.control_callback)
        
        self.get_logger().info(
            f'Strategic RL node started '
            f'(drones: {self.num_drones}, rate: {update_rate} Hz, '
            f'baseline: {self.use_baseline})'
        )
    
    def swarm_callback(self, msg: SwarmState):
        """Handle swarm state update"""
        self.latest_swarm = msg
    
    def metrics_callback(self, msg: NetworkMetrics):
        """Handle network metrics update"""
        self.latest_metrics = msg
    
    def mission_callback(self, msg: MissionStatus):
        """Handle mission status update"""
        self.current_phase = MissionPhase(msg.current_phase)
        
        # RL only active in OPERATIONS phase
        old_active = self.rl_active
        self.rl_active = (self.current_phase == MissionPhase.OPERATIONS)
        
        if self.rl_active and not old_active:
            self.get_logger().info('Entering OPERATIONS phase - RL policy activated')
        elif not self.rl_active and old_active:
            self.get_logger().info('Exiting OPERATIONS phase - RL policy deactivated')
    
    def control_callback(self):
        """Main control loop"""
        if self.latest_swarm is None:
            return
        
        # Get current positions
        current_positions = []
        for drone in self.latest_swarm.drones:
            pos = (drone.position.x, drone.position.y, drone.position.z)
            current_positions.append(pos)
        
        # Pad if fewer drones than expected
        while len(current_positions) < self.num_drones:
            current_positions.append((0.0, 0.0, 30.0))
        
        # Get actions
        if self.rl_active and self.policy is not None:
            goal_positions = self._get_rl_actions(current_positions)
        else:
            goal_positions = self._get_baseline_actions(current_positions)
        
        # Publish goals
        self._publish_goals(goal_positions)
    
    def _get_rl_actions(self, 
                        current_positions: List[Tuple[float, float, float]]
                        ) -> List[Tuple[float, float, float]]:
        """Get actions from RL policy"""
        import torch
        
        # Build observation
        obs = self.obs_builder.build_from_messages(
            self.latest_swarm,
            self.latest_metrics,
            []  # No weather zones for now
        )
        
        # Convert to tensor
        obs_tensor = torch.FloatTensor(obs).unsqueeze(0)
        
        # Get action
        with torch.no_grad():
            action, _, _ = self.policy.get_action(obs_tensor, deterministic=True)
            action = action.squeeze(0).numpy()
        
        # Process into goal positions
        goal_positions = self.action_processor.process_actions(action, current_positions)
        
        return goal_positions
    
    def _get_baseline_actions(self,
                               current_positions: List[Tuple[float, float, float]]
                               ) -> List[Tuple[float, float, float]]:
        """Get actions from baseline controller"""
        positions = [np.array(p) for p in current_positions]
        
        if isinstance(self.baseline, GridFormationController):
            return [tuple(p) for p in self.baseline.get_goal_positions(positions)]
        
        elif isinstance(self.baseline, CentroidSpreadController):
            actions = self.baseline.get_actions(positions)
            return self.action_processor.process_actions(actions, current_positions)
        
        else:
            # Fallback: hold position
            return current_positions
    
    def _publish_goals(self, goal_positions: List[Tuple[float, float, float]]):
        """Publish coverage goals for each drone"""
        if not MSGS_AVAILABLE:
            return
        
        timestamp = self.get_clock().now().to_msg()
        
        for i, goal in enumerate(goal_positions[:self.num_drones]):
            if i not in self.goal_pubs:
                continue
            
            msg = CoverageGoal()
            msg.header = Header()
            msg.header.stamp = timestamp
            msg.header.frame_id = 'map'
            
            msg.drone_id = i
            msg.goal_position = Point(x=goal[0], y=goal[1], z=goal[2])
            msg.priority = 1.0
            msg.radius_meters = 50.0  # Coverage radius
            
            self.goal_pubs[i].publish(msg)


def main(args=None):
    rclpy.init(args=args)
    
    node = StrategicRLNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
