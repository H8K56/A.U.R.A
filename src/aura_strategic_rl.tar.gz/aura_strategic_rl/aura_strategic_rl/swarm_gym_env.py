"""
Gymnasium Environment for A.U.R.A. Swarm Training

Provides a standalone training environment that simulates:
- Drone swarm dynamics
- Network coverage (using aura_network_sim models)
- Weather effects
- Reward computation

Can run without ROS for faster training, then deploy trained
policy via strategic_rl_node.
"""

import numpy as np
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass

try:
    import gymnasium as gym
    from gymnasium import spaces
    GYM_AVAILABLE = True
except ImportError:
    GYM_AVAILABLE = False
    # Create stub for type hints
    class gym:
        class Env:
            pass
        class spaces:
            class Box:
                pass

from .spaces import ObservationConfig, ActionConfig, ObservationBuilder, ActionProcessor
from .rewards import RewardConfig, RewardCalculator


@dataclass
class EnvConfig:
    """Environment configuration"""
    
    # Simulation
    num_drones: int = 5
    max_steps: int = 500
    dt: float = 0.5  # Time step (seconds)
    
    # Area
    area_size: float = 200.0
    grid_resolution: float = 10.0
    
    # Drone dynamics
    max_velocity: float = 5.0  # m/s
    max_acceleration: float = 2.0  # m/s^2
    
    # Initial formation
    initial_radius: float = 30.0
    initial_altitude: float = 30.0
    
    # Network simulation
    tx_power_dbm: float = 20.0
    noise_floor_dbm: float = -100.0
    path_loss_exponent: float = 2.7
    max_mesh_distance: float = 150.0
    
    # Randomization (for domain randomization)
    randomize_initial_positions: bool = True
    randomize_weather: bool = False
    weather_probability: float = 0.3


class DroneState:
    """State of a single drone"""
    
    def __init__(self, drone_id: int, position: np.ndarray):
        self.drone_id = drone_id
        self.position = position.copy()
        self.velocity = np.zeros(3)
        self.battery = 100.0
        self.is_hub = (drone_id == 0)
        
        # Network state (computed by simulation)
        self.signal_strength_dbm = -70.0
        self.throughput_mbps = 50.0
        self.latency_ms = 10.0
        self.neighbors = []


class WeatherZone:
    """Simulated weather zone"""
    
    def __init__(self, x: float, y: float, radius: float, attenuation_db: float):
        self.center = np.array([x, y])
        self.radius = radius
        self.attenuation_db = attenuation_db
        self.is_active = True


class SwarmGymEnv(gym.Env if GYM_AVAILABLE else object):
    """
    Gymnasium environment for A.U.R.A. swarm training.
    
    Observation: ~140-dimensional vector (see spaces.py)
    Action: num_drones * 3 position deltas
    Reward: Multi-objective (coverage + network + safety)
    """
    
    metadata = {'render_modes': ['human', 'rgb_array']}
    
    def __init__(self, config: EnvConfig = None, render_mode: str = None):
        super().__init__()
        
        self.config = config or EnvConfig()
        self.render_mode = render_mode
        
        # Create configs
        self.obs_config = ObservationConfig(num_drones=self.config.num_drones)
        self.action_config = ActionConfig(num_drones=self.config.num_drones)
        self.reward_config = RewardConfig()
        
        # Create helpers
        self.obs_builder = ObservationBuilder(self.obs_config)
        self.action_processor = ActionProcessor(self.action_config)
        self.reward_calculator = RewardCalculator(self.reward_config)
        
        # Define spaces
        if GYM_AVAILABLE:
            self.observation_space = spaces.Box(
                low=-np.inf,
                high=np.inf,
                shape=(self.obs_config.total_obs_dim,),
                dtype=np.float32
            )
            
            self.action_space = spaces.Box(
                low=-1.0,
                high=1.0,
                shape=(self.action_config.action_dim,),
                dtype=np.float32
            )
        
        # State
        self.drones: List[DroneState] = []
        self.weather_zones: List[WeatherZone] = []
        self.step_count = 0
        self.coverage_history = []
        
        # Coverage grid (simplified simulation)
        self._init_coverage_grid()
    
    def _init_coverage_grid(self):
        """Initialize coverage grid for simulation"""
        size = int(2 * self.config.area_size / self.config.grid_resolution)
        self.grid_size = size
        self.coverage_grid = np.zeros((size, size), dtype=np.float32)
        self.signal_grid = np.full((size, size), -200.0, dtype=np.float32)
    
    def reset(self, seed: int = None, options: Dict = None) -> Tuple[np.ndarray, Dict]:
        """Reset environment to initial state"""
        if seed is not None:
            np.random.seed(seed)
        
        self.step_count = 0
        self.coverage_history = []
        self.reward_calculator.reset()
        
        # Initialize drones
        self.drones = []
        for i in range(self.config.num_drones):
            if self.config.randomize_initial_positions:
                angle = 2 * np.pi * i / self.config.num_drones + np.random.uniform(-0.2, 0.2)
                radius = self.config.initial_radius * np.random.uniform(0.8, 1.2)
            else:
                angle = 2 * np.pi * i / self.config.num_drones
                radius = self.config.initial_radius
            
            position = np.array([
                radius * np.cos(angle),
                radius * np.sin(angle),
                self.config.initial_altitude + np.random.uniform(-2, 2)
            ])
            
            self.drones.append(DroneState(i, position))
        
        # Initialize weather
        self.weather_zones = []
        if self.config.randomize_weather and np.random.random() < self.config.weather_probability:
            # Add random weather zone
            self.weather_zones.append(WeatherZone(
                x=np.random.uniform(-100, 100),
                y=np.random.uniform(-100, 100),
                radius=np.random.uniform(20, 50),
                attenuation_db=np.random.uniform(5, 15)
            ))
        
        # Compute initial network state
        self._simulate_network()
        
        # Build observation
        obs = self._build_observation()
        info = self._get_info()
        
        return obs, info
    
    def step(self, action: np.ndarray) -> Tuple[np.ndarray, float, bool, bool, Dict]:
        """Execute one environment step"""
        self.step_count += 1
        
        # Get current positions
        current_positions = [tuple(d.position) for d in self.drones]
        
        # Process actions into goal positions
        goal_positions = self.action_processor.process_actions(action, current_positions)
        
        # Apply actions (simple kinematics)
        movement_magnitudes = []
        for drone, goal in zip(self.drones, goal_positions):
            delta = np.array(goal) - drone.position
            movement_magnitudes.append(np.linalg.norm(delta))
            
            # Simple velocity-limited movement
            dist = np.linalg.norm(delta)
            if dist > 0:
                direction = delta / dist
                move_dist = min(dist, self.config.max_velocity * self.config.dt)
                drone.position += direction * move_dist
                drone.velocity = direction * move_dist / self.config.dt
            else:
                drone.velocity = np.zeros(3)
            
            # Battery drain
            drone.battery -= 0.01 * (1 + np.linalg.norm(drone.velocity))
        
        # Simulate network
        self._simulate_network()
        
        # Compute coverage
        coverage_percent, avg_signal = self._compute_coverage()
        mesh_connected = self._check_mesh_connected()
        
        self.coverage_history.append(coverage_percent)
        
        # Get network stats
        avg_throughput = np.mean([d.throughput_mbps for d in self.drones])
        avg_latency = np.mean([d.latency_ms for d in self.drones])
        
        # Compute reward
        drone_positions = [tuple(d.position) for d in self.drones]
        reward, reward_components = self.reward_calculator.compute_reward(
            coverage_percent=coverage_percent,
            mesh_connected=mesh_connected,
            avg_signal_dbm=avg_signal,
            avg_throughput_mbps=avg_throughput,
            avg_latency_ms=avg_latency,
            drone_positions=drone_positions,
            movement_magnitudes=movement_magnitudes,
        )
        
        # Check termination
        terminated = False
        truncated = False
        
        # Terminate if battery depleted
        if any(d.battery <= 0 for d in self.drones):
            terminated = True
        
        # Truncate if max steps reached
        if self.step_count >= self.config.max_steps:
            truncated = True
        
        # Build observation and info
        obs = self._build_observation()
        info = self._get_info()
        info['reward_components'] = reward_components
        
        return obs, reward, terminated, truncated, info
    
    def _simulate_network(self):
        """Simulate network connectivity and metrics"""
        n = len(self.drones)
        
        for i, drone in enumerate(self.drones):
            drone.neighbors = []
            best_rssi = -200.0
            
            for j, other in enumerate(self.drones):
                if i == j:
                    continue
                
                dist = np.linalg.norm(drone.position - other.position)
                
                # Check max mesh distance
                if dist > self.config.max_mesh_distance:
                    continue
                
                # Compute RSSI (log-distance model)
                if dist < 1.0:
                    dist = 1.0
                
                path_loss = 46.4 + 10 * self.config.path_loss_exponent * np.log10(dist)
                
                # Weather attenuation
                for zone in self.weather_zones:
                    midpoint = (drone.position[:2] + other.position[:2]) / 2
                    if np.linalg.norm(midpoint - zone.center) < zone.radius:
                        path_loss += zone.attenuation_db
                
                rssi = self.config.tx_power_dbm + 6 - path_loss  # 6 dB antenna gain
                
                # Check connectivity
                rx_sensitivity = self.config.noise_floor_dbm + 10  # min_snr = 10 dB
                if rssi > rx_sensitivity:
                    drone.neighbors.append(j)
                    if rssi > best_rssi:
                        best_rssi = rssi
            
            drone.signal_strength_dbm = best_rssi
            
            # Estimate throughput from RSSI
            snr = best_rssi - self.config.noise_floor_dbm
            if snr > 25:
                drone.throughput_mbps = 100.0
            elif snr > 15:
                drone.throughput_mbps = 50.0
            elif snr > 10:
                drone.throughput_mbps = 20.0
            else:
                drone.throughput_mbps = 0.0
            
            # Estimate latency from hop count
            drone.latency_ms = 5.0 + len(drone.neighbors) * 2.0
    
    def _compute_coverage(self) -> Tuple[float, float]:
        """Compute ground coverage from drone positions"""
        self.coverage_grid.fill(0)
        self.signal_grid.fill(-200.0)
        
        res = self.config.grid_resolution
        half_size = self.config.area_size
        
        for iy in range(self.grid_size):
            for ix in range(self.grid_size):
                x = -half_size + ix * res
                y = -half_size + iy * res
                ground_pos = np.array([x, y, 0])
                
                best_rssi = -200.0
                
                for drone in self.drones:
                    dist = np.linalg.norm(ground_pos - drone.position)
                    if dist < 1.0:
                        dist = 1.0
                    
                    # Air-to-ground path loss (slightly worse)
                    path_loss = 40.0 + 10 * 2.8 * np.log10(dist)
                    rssi = self.config.tx_power_dbm + 4 - path_loss
                    
                    if rssi > best_rssi:
                        best_rssi = rssi
                
                self.signal_grid[iy, ix] = best_rssi
                self.coverage_grid[iy, ix] = 1.0 if best_rssi > -80.0 else 0.0
        
        coverage_percent = 100.0 * np.mean(self.coverage_grid)
        covered_mask = self.coverage_grid > 0
        avg_signal = np.mean(self.signal_grid[covered_mask]) if np.any(covered_mask) else -200.0
        
        return coverage_percent, avg_signal
    
    def _check_mesh_connected(self) -> bool:
        """Check if all drones form connected mesh"""
        n = len(self.drones)
        if n <= 1:
            return True
        
        visited = {0}
        queue = [0]
        
        while queue:
            current = queue.pop(0)
            for neighbor in self.drones[current].neighbors:
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)
        
        return len(visited) == n
    
    def _build_observation(self) -> np.ndarray:
        """Build observation vector"""
        # Create mock message-like objects for observation builder
        obs_parts = []
        
        # Drone observations
        drone_obs = np.zeros((self.config.num_drones, self.obs_config.drone_obs_dim))
        for i, drone in enumerate(self.drones):
            idx = 0
            drone_obs[i, idx:idx+3] = drone.position / 200.0
            idx += 3
            drone_obs[i, idx:idx+3] = drone.velocity / 5.0
            idx += 3
            drone_obs[i, idx:idx+3] = [
                drone.battery / 100.0,
                (drone.signal_strength_dbm + 100) / 50.0,
                len(drone.neighbors) / self.config.num_drones,
            ]
            idx += 3
            drone_obs[i, idx:idx+4] = [
                drone.throughput_mbps / 100.0,
                drone.latency_ms / 100.0,
                0.0,
                1.0 if drone.is_hub else 0.0,
            ]
        obs_parts.append(drone_obs.flatten())
        
        # Coverage grid (downsampled)
        grid_size = self.obs_config.coverage_grid_size
        step = max(1, self.grid_size // grid_size)
        downsampled = self.coverage_grid[::step, ::step][:grid_size, :grid_size]
        coverage_obs = np.zeros(grid_size * grid_size)
        h, w = downsampled.shape
        coverage_obs[:h*w] = downsampled.flatten()[:h*w]
        obs_parts.append(coverage_obs)
        
        # Network metrics
        coverage_pct = 100.0 * np.mean(self.coverage_grid)
        covered = self.coverage_grid > 0
        avg_sig = np.mean(self.signal_grid[covered]) if np.any(covered) else -100
        network_obs = np.array([
            coverage_pct / 100.0,
            (avg_sig + 100) / 50.0,
            np.mean([d.throughput_mbps for d in self.drones]) / 100.0,
            np.mean([d.latency_ms for d in self.drones]) / 100.0,
        ])
        obs_parts.append(network_obs)
        
        # Weather (padded)
        weather_obs = np.zeros(self.obs_config.num_weather_zones * self.obs_config.weather_zone_dim)
        for i, zone in enumerate(self.weather_zones[:self.obs_config.num_weather_zones]):
            idx = i * 5
            weather_obs[idx:idx+5] = [
                zone.center[0] / 200.0,
                zone.center[1] / 200.0,
                zone.radius / 200.0,
                zone.attenuation_db / 20.0,
                1.0 if zone.is_active else 0.0,
            ]
        obs_parts.append(weather_obs)
        
        return np.concatenate(obs_parts).astype(np.float32)
    
    def _get_info(self) -> Dict[str, Any]:
        """Get info dictionary"""
        coverage_pct = 100.0 * np.mean(self.coverage_grid)
        covered = self.coverage_grid > 0
        
        return {
            'step': self.step_count,
            'coverage_percent': coverage_pct,
            'mesh_connected': self._check_mesh_connected(),
            'avg_signal_dbm': np.mean(self.signal_grid[covered]) if np.any(covered) else -200,
            'avg_throughput_mbps': np.mean([d.throughput_mbps for d in self.drones]),
            'avg_battery': np.mean([d.battery for d in self.drones]),
            'drone_positions': [tuple(d.position) for d in self.drones],
        }
    
    def render(self):
        """Render environment (placeholder)"""
        if self.render_mode == 'human':
            info = self._get_info()
            print(f"Step {info['step']}: Coverage={info['coverage_percent']:.1f}%, "
                  f"Mesh={'OK' if info['mesh_connected'] else 'BROKEN'}, "
                  f"Battery={info['avg_battery']:.1f}%")
    
    def close(self):
        """Clean up resources"""
        pass


def main():
    """Test the environment"""
    if not GYM_AVAILABLE:
        print("Gymnasium not installed. Run: pip install gymnasium")
        return
    
    env = SwarmGymEnv(render_mode='human')
    obs, info = env.reset(seed=42)
    
    print(f"Observation shape: {obs.shape}")
    print(f"Action shape: {env.action_space.shape}")
    print(f"Initial info: {info}")
    
    total_reward = 0
    for i in range(100):
        action = env.action_space.sample()
        obs, reward, terminated, truncated, info = env.step(action)
        total_reward += reward
        
        if i % 20 == 0:
            env.render()
        
        if terminated or truncated:
            break
    
    print(f"\nTotal reward: {total_reward:.2f}")
    print(f"Final coverage: {info['coverage_percent']:.1f}%")
    
    env.close()


if __name__ == '__main__':
    main()
