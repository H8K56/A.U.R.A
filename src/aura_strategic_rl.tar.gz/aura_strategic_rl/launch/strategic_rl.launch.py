"""
Strategic RL Launch File

Launches the strategic RL node with configuration.
Can run with trained policy or baseline controller.
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
import os
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    # Get package directory
    pkg_dir = get_package_share_directory('aura_strategic_rl')
    config_file = os.path.join(pkg_dir, 'config', 'strategic_rl_params.yaml')
    
    # Launch arguments
    num_drones_arg = DeclareLaunchArgument(
        'num_drones',
        default_value='5',
        description='Number of drones in swarm'
    )
    
    policy_path_arg = DeclareLaunchArgument(
        'policy_path',
        default_value='',
        description='Path to trained policy checkpoint'
    )
    
    use_baseline_arg = DeclareLaunchArgument(
        'use_baseline',
        default_value='true',
        description='Use baseline controller instead of RL'
    )
    
    baseline_type_arg = DeclareLaunchArgument(
        'baseline_type',
        default_value='spread',
        description='Baseline type: spread, grid, or hho'
    )
    
    # Strategic RL node
    strategic_rl_node = Node(
        package='aura_strategic_rl',
        executable='strategic_rl_node',
        name='strategic_rl',
        parameters=[
            config_file,
            {
                'num_drones': LaunchConfiguration('num_drones'),
                'policy_path': LaunchConfiguration('policy_path'),
                'use_baseline': LaunchConfiguration('use_baseline'),
                'baseline_type': LaunchConfiguration('baseline_type'),
            }
        ],
        output='screen',
        emulate_tty=True,
    )
    
    return LaunchDescription([
        num_drones_arg,
        policy_path_arg,
        use_baseline_arg,
        baseline_type_arg,
        strategic_rl_node,
    ])
