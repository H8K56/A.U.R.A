#!/usr/bin/env python3
"""
Standalone Test for Strategic RL Package

Tests the RL components without ROS 2:
- Gymnasium environment
- Observation/action processing
- Reward calculation
- Baseline controllers

Usage: python3 test_strategic_rl.py
"""

import sys
import os
import numpy as np

# Add package to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from aura_strategic_rl.spaces import ObservationConfig, ActionConfig, ActionProcessor
from aura_strategic_rl.rewards import RewardConfig, RewardCalculator
from aura_strategic_rl.baseline_controller import (
    GridFormationController, 
    CentroidSpreadController,
    HarrisHawksOptimizer,
    ControllerConfig
)


def test_observation_config():
    """Test observation space configuration"""
    print("\n" + "="*60)
    print("Test 1: Observation Configuration")
    print("="*60)
    
    config = ObservationConfig(num_drones=5)
    
    print(f"  Number of drones: {config.num_drones}")
    print(f"  Per-drone obs dim: {config.drone_obs_dim}")
    print(f"  Coverage grid: {config.coverage_grid_size}x{config.coverage_grid_size}")
    print(f"  Total observation dim: {config.total_obs_dim}")
    
    # Breakdown
    drone_total = config.num_drones * config.drone_obs_dim
    coverage_total = config.coverage_grid_size ** 2
    network_total = config.network_metrics_dim
    weather_total = config.num_weather_zones * config.weather_zone_dim
    
    print(f"\n  Breakdown:")
    print(f"    Drone states: {drone_total}")
    print(f"    Coverage grid: {coverage_total}")
    print(f"    Network metrics: {network_total}")
    print(f"    Weather zones: {weather_total}")
    print(f"    Total: {drone_total + coverage_total + network_total + weather_total}")
    
    return True


def test_action_processing():
    """Test action processing"""
    print("\n" + "="*60)
    print("Test 2: Action Processing")
    print("="*60)
    
    config = ActionConfig(num_drones=5)
    processor = ActionProcessor(config)
    
    print(f"  Action dimension: {config.action_dim}")
    print(f"  Max delta XY: {config.max_delta_xy}m")
    print(f"  Max delta Z: {config.max_delta_z}m")
    
    # Test with sample action
    current_positions = [
        (0, 0, 30),
        (50, 0, 30),
        (-50, 0, 30),
        (0, 50, 30),
        (0, -50, 30),
    ]
    
    # Action: all drones move +X
    raw_action = np.zeros(15)
    raw_action[0::3] = 0.5  # X direction
    
    goals = processor.process_actions(raw_action, current_positions)
    
    print(f"\n  Sample action test (move +X):")
    for i, (cur, goal) in enumerate(zip(current_positions, goals)):
        dx = goal[0] - cur[0]
        dy = goal[1] - cur[1]
        dz = goal[2] - cur[2]
        print(f"    Drone {i}: ({cur[0]:.1f}, {cur[1]:.1f}) -> ({goal[0]:.1f}, {goal[1]:.1f}) "
              f"delta=({dx:.1f}, {dy:.1f}, {dz:.1f})")
    
    # Test boundary clamping (single drone test with proper dimensions)
    single_config = ActionConfig(num_drones=1)
    single_processor = ActionProcessor(single_config)
    extreme_positions = [(190, 190, 30)]
    extreme_action = np.array([1.0, 1.0, 0.0])  # Try to move out of bounds
    
    goal = single_processor.process_actions(extreme_action, extreme_positions)[0]
    print(f"\n  Boundary test:")
    print(f"    Position (190, 190) + action (max, max)")
    print(f"    Result: ({goal[0]:.1f}, {goal[1]:.1f}) - clamped to {single_config.area_bound}")
    
    return True


def test_reward_calculation():
    """Test reward calculation"""
    print("\n" + "="*60)
    print("Test 3: Reward Calculation")
    print("="*60)
    
    config = RewardConfig()
    calculator = RewardCalculator(config)
    
    print(f"  Reward weights:")
    print(f"    Coverage: {config.coverage_weight}")
    print(f"    Connectivity: {config.connectivity_weight}")
    print(f"    Throughput: {config.throughput_weight}")
    
    # Test scenarios
    scenarios = [
        {
            'name': 'Good state',
            'coverage': 85.0,
            'connected': True,
            'signal': -65.0,
            'throughput': 80.0,
            'latency': 15.0,
        },
        {
            'name': 'Disconnected',
            'coverage': 90.0,
            'connected': False,
            'signal': -70.0,
            'throughput': 50.0,
            'latency': 20.0,
        },
        {
            'name': 'Low coverage',
            'coverage': 40.0,
            'connected': True,
            'signal': -60.0,
            'throughput': 90.0,
            'latency': 10.0,
        },
    ]
    
    positions = [(0, 0, 30), (30, 0, 30), (-30, 0, 30), (0, 30, 30), (0, -30, 30)]
    
    print(f"\n  Scenario tests:")
    for scenario in scenarios:
        calculator.reset()
        reward, components = calculator.compute_reward(
            coverage_percent=scenario['coverage'],
            mesh_connected=scenario['connected'],
            avg_signal_dbm=scenario['signal'],
            avg_throughput_mbps=scenario['throughput'],
            avg_latency_ms=scenario['latency'],
            drone_positions=positions,
        )
        
        print(f"\n    {scenario['name']}:")
        print(f"      Coverage: {scenario['coverage']}%, Connected: {scenario['connected']}")
        print(f"      Total reward: {reward:.3f}")
        print(f"      Components: coverage={components['coverage']:.2f}, "
              f"connectivity={components['connectivity']:.2f}")
    
    return True


def test_baseline_controllers():
    """Test baseline controllers"""
    print("\n" + "="*60)
    print("Test 4: Baseline Controllers")
    print("="*60)
    
    config = ControllerConfig(num_drones=5)
    
    # Initial positions (clustered)
    positions = [
        np.array([5, 5, 30]),
        np.array([8, 3, 30]),
        np.array([3, 8, 30]),
        np.array([6, 6, 30]),
        np.array([4, 4, 30]),
    ]
    
    print(f"\n  Initial positions (clustered near origin):")
    for i, p in enumerate(positions):
        print(f"    Drone {i}: ({p[0]:.1f}, {p[1]:.1f}, {p[2]:.1f})")
    
    # Test Grid Formation
    print(f"\n  Grid Formation Controller:")
    grid = GridFormationController(config)
    grid_goals = grid.get_goal_positions(positions)
    
    for i, g in enumerate(grid_goals):
        print(f"    Drone {i} goal: ({g[0]:.1f}, {g[1]:.1f}, {g[2]:.1f})")
    
    # Test Centroid Spread
    print(f"\n  Centroid Spread Controller:")
    spread = CentroidSpreadController(config)
    spread_actions = spread.get_actions(positions)
    
    print(f"    Action shape: {spread_actions.shape}")
    print(f"    Action range: [{spread_actions.min():.2f}, {spread_actions.max():.2f}]")
    
    # Apply actions to see movement
    for i in range(5):
        action = spread_actions[i*3:(i+1)*3]
        new_pos = positions[i] + action * 10  # Scale by max_delta
        print(f"    Drone {i}: action=({action[0]:.2f}, {action[1]:.2f}), "
              f"would move to ({new_pos[0]:.1f}, {new_pos[1]:.1f})")
    
    return True


def test_gymnasium_env():
    """Test Gymnasium environment"""
    print("\n" + "="*60)
    print("Test 5: Gymnasium Environment")
    print("="*60)
    
    try:
        from aura_strategic_rl.swarm_gym_env import SwarmGymEnv, EnvConfig, GYM_AVAILABLE
    except ImportError as e:
        print(f"  Could not import environment: {e}")
        return False
    
    if not GYM_AVAILABLE:
        print("  Gymnasium not installed. Skipping environment test.")
        print("  Install with: pip install gymnasium")
        return True
    
    config = EnvConfig(num_drones=5, max_steps=100)
    env = SwarmGymEnv(config)
    
    print(f"  Environment created:")
    print(f"    Observation space: {env.observation_space.shape}")
    print(f"    Action space: {env.action_space.shape}")
    
    # Reset
    obs, info = env.reset(seed=42)
    print(f"\n  After reset:")
    print(f"    Observation shape: {obs.shape}")
    print(f"    Coverage: {info['coverage_percent']:.1f}%")
    print(f"    Mesh connected: {info['mesh_connected']}")
    
    # Run a few steps
    print(f"\n  Running 20 steps with random actions:")
    total_reward = 0
    
    for step in range(20):
        action = env.action_space.sample()
        obs, reward, terminated, truncated, info = env.step(action)
        total_reward += reward
        
        if step % 5 == 0:
            print(f"    Step {step}: reward={reward:.2f}, "
                  f"coverage={info['coverage_percent']:.1f}%, "
                  f"connected={info['mesh_connected']}")
        
        if terminated or truncated:
            break
    
    print(f"\n  Total reward: {total_reward:.2f}")
    print(f"  Final coverage: {info['coverage_percent']:.1f}%")
    
    env.close()
    return True


def test_hho_optimizer():
    """Test Harris Hawks Optimizer"""
    print("\n" + "="*60)
    print("Test 6: Harris Hawks Optimizer")
    print("="*60)
    
    config = ControllerConfig(num_drones=5)
    hho = HarrisHawksOptimizer(config)
    
    # Initial positions
    positions = [
        np.array([10, 10, 30]),
        np.array([15, 5, 30]),
        np.array([5, 15, 30]),
        np.array([12, 12, 30]),
        np.array([8, 8, 30]),
    ]
    
    print(f"  Initial positions (clustered):")
    for i, p in enumerate(positions):
        print(f"    Drone {i}: ({p[0]:.1f}, {p[1]:.1f})")
    
    # Simple coverage function
    def coverage_func(pos_list):
        # Reward spread
        centroid = np.mean([p[:2] for p in pos_list], axis=0)
        distances = [np.linalg.norm(p[:2] - centroid) for p in pos_list]
        return np.mean(distances)  # Higher spread = better
    
    # Simple connectivity function
    def connectivity_func(pos_list):
        # Check all pairs within 100m
        for i in range(len(pos_list)):
            for j in range(i+1, len(pos_list)):
                if np.linalg.norm(pos_list[i] - pos_list[j]) > 100:
                    return False
        return True
    
    print(f"\n  Running HHO optimization (10 iterations)...")
    optimized = hho.optimize(
        positions, 
        coverage_func, 
        connectivity_func,
        max_iterations=10
    )
    
    print(f"\n  Optimized positions:")
    for i, p in enumerate(optimized):
        print(f"    Drone {i}: ({p[0]:.1f}, {p[1]:.1f})")
    
    initial_score = coverage_func(positions)
    final_score = coverage_func(optimized)
    print(f"\n  Coverage score: {initial_score:.1f} -> {final_score:.1f}")
    
    return True


def run_all_tests():
    """Run all tests"""
    print("\n" + "="*60)
    print("A.U.R.A. Strategic RL - Standalone Tests")
    print("="*60)
    
    tests = [
        ("Observation Config", test_observation_config),
        ("Action Processing", test_action_processing),
        ("Reward Calculation", test_reward_calculation),
        ("Baseline Controllers", test_baseline_controllers),
        ("Gymnasium Environment", test_gymnasium_env),
        ("HHO Optimizer", test_hho_optimizer),
    ]
    
    results = []
    for name, test_func in tests:
        try:
            passed = test_func()
            results.append((name, passed))
        except Exception as e:
            print(f"\n  ERROR in {name}: {e}")
            import traceback
            traceback.print_exc()
            results.append((name, False))
    
    # Summary
    print("\n" + "="*60)
    print("Test Summary")
    print("="*60)
    
    all_passed = True
    for name, passed in results:
        status = "✓ PASS" if passed else "✗ FAIL"
        print(f"  {name}: {status}")
        if not passed:
            all_passed = False
    
    print()
    if all_passed:
        print("All tests passed! Strategic RL package is ready.")
    else:
        print("Some tests failed. Please check the output above.")
    
    return all_passed


if __name__ == '__main__':
    success = run_all_tests()
    sys.exit(0 if success else 1)
